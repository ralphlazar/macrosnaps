"""
Updated Flask API for MacroSnaps with Multi-Level Expertise Support
Filters content based on user's selected expertise level
"""
from flask import Flask, jsonify, send_file, request
from flask_cors import CORS
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData, Card
from backend.utils.calculations import calculate_yoy_inflation, calculate_historical_yoy_inflation
from backend.services.forecast_loader import get_custom_forecasts
from datetime import date, timedelta
import os

app = Flask(__name__, static_folder='../viewer', static_url_path='')
CORS(app)


@app.route('/')
def index():
    """Serve the viewer HTML"""
    return send_file('../viewer/viewer.html')


# Load custom forecasts once at startup
print("Loading custom forecasts from Google Sheet...")
custom_forecasts = get_custom_forecasts()


def get_custom_forecast(country_code, metric_code):
    """Get 2026 forecast from Google Sheet"""
    if custom_forecasts and country_code in custom_forecasts:
        return custom_forecasts[country_code].get(metric_code)
    return None


@app.route('/api/cards')
def get_cards():
    """
    Get all economic cards with their latest data
    Supports expertise level filtering via ?level=beginner|moderate|expert
    Default: moderate
    """
    # Get expertise level from query parameter
    expertise_level = request.args.get('level', 'moderate').lower()
    
    # Validate expertise level
    if expertise_level not in ['beginner', 'moderate', 'expert']:
        return jsonify({'error': 'Invalid expertise level. Must be beginner, moderate, or expert'}), 400
    
    with get_db() as db:
        today = date.today()
        
        cards_data = []
        
        # Helper function to calculate trend
        def get_trend(country_id, metric_id, is_positive_good=True):
            """Calculate trend from last 3 data points"""
            recent_data = db.query(DailyData).filter_by(
                country_id=country_id,
                metric_id=metric_id
            ).order_by(DailyData.date.desc()).limit(3).all()
            
            if len(recent_data) < 2:
                return '→', 'insufficient data', 'neutral'
            
            latest = recent_data[0].value
            previous = recent_data[-1].value
            
            change = latest - previous
            pct_change = (change / abs(previous)) * 100 if previous != 0 else 0
            
            # Determine direction
            if abs(pct_change) < 0.1:
                arrow = '→'
                description = 'stable'
                color = 'neutral'
            elif change > 0:
                arrow = '↗'
                description = 'has been rising'
                color = 'good' if is_positive_good else 'bad'
            else:
                arrow = '↘'
                description = 'has been falling'
                color = 'bad' if is_positive_good else 'good'
            
            return arrow, description, color
        
        for country in db.query(Country).order_by(Country.display_order).all():
            card = db.query(Card).filter_by(
                country_id=country.id,
                date=today
            ).first()
            
            if not card:
                continue
            
            # Get the appropriate headline and story based on expertise level
            if expertise_level == 'beginner':
                headline = card.headline_beginner
                story = card.story_beginner
            elif expertise_level == 'expert':
                headline = card.headline_expert
                story = card.story_expert
            else:  # moderate (default)
                headline = card.headline_moderate
                story = card.story_moderate
            
            macro_metrics = ['gdp_growth', 'inflation', 'budget_deficit', 'current_account']
            market_metrics = ['policy_rate', 'stock_index', 'bond_yield', 'currency']
            
            macro_data = []
            market_data = []
            
            metrics = {m.code: m for m in db.query(Metric).all()}
            
            # Historical data from 2020
            since_2020 = date(2020, 1, 1)
            
            # MACROECONOMICS
            for metric_code in macro_metrics:
                metric = metrics.get(metric_code)
                if not metric:
                    continue
                
                # Get tooltip for current expertise level
                if expertise_level == 'beginner':
                    tooltip = metric.tooltip_beginner
                elif expertise_level == 'expert':
                    tooltip = metric.tooltip_expert
                else:
                    tooltip = metric.tooltip_moderate
                
                forecast_2026 = get_custom_forecast(country.code, metric_code)
                
                if metric_code == 'inflation':
                    if country.code == 'CAN':
                        latest = db.query(DailyData).filter_by(
                            country_id=country.id,
                            metric_id=metric.id
                        ).order_by(DailyData.date.desc()).first()
                        
                        if latest:
                            historical = db.query(DailyData).filter(
                                DailyData.country_id == country.id,
                                DailyData.metric_id == metric.id,
                                DailyData.date >= since_2020
                            ).order_by(DailyData.date).all()
                            
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 1)} for h in historical]
                            arrow, desc, color = get_trend(country.id, metric.id, is_positive_good=False)
                            
                            macro_data.append({
                                'name': 'Inflation (CPI)',
                                'actual_value': f"{round(latest.value, 1)}%",
                                'actual_date': latest.date.strftime('%b %Y'),
                                'forecast_2026': f"{round(forecast_2026, 1)}%" if forecast_2026 else None,
                                'display_value': f"{round(forecast_2026, 1)}%" if forecast_2026 else f"{round(latest.value, 1)}%",
                                'display_label': '2026F' if forecast_2026 else latest.date.strftime('%b %Y'),
                                'historical': historical_data,
                                'trend': {'arrow': arrow, 'description': desc, 'color': color},
                                'tooltip': tooltip
                            })
                        else:
                            macro_data.append({
                                'name': 'Inflation (CPI)',
                                'actual_value': 'N/A',
                                'actual_date': 'No data',
                                'forecast_2026': f"{round(forecast_2026, 1)}%" if forecast_2026 else None,
                                'display_value': f"{round(forecast_2026, 1)}%" if forecast_2026 else 'N/A',
                                'display_label': '2026F' if forecast_2026 else '',
                                'historical': [],
                                'trend': None,
                                'tooltip': tooltip
                            })
                    else:
                        rate, as_of = calculate_yoy_inflation(country.code)
                        if rate is not None:
                            historical_data = calculate_historical_yoy_inflation(country.code, since_date=since_2020)
                            arrow, desc, color = get_trend(country.id, metric.id, is_positive_good=False)
                            
                            macro_data.append({
                                'name': 'Inflation (CPI)',
                                'actual_value': f"{rate}%",
                                'actual_date': as_of.strftime('%b %Y'),
                                'forecast_2026': f"{round(forecast_2026, 1)}%" if forecast_2026 else None,
                                'display_value': f"{round(forecast_2026, 1)}%" if forecast_2026 else f"{rate}%",
                                'display_label': '2026F' if forecast_2026 else as_of.strftime('%b %Y'),
                                'historical': historical_data,
                                'trend': {'arrow': arrow, 'description': desc, 'color': color},
                                'tooltip': tooltip
                            })
                        else:
                            macro_data.append({
                                'name': 'Inflation (CPI)',
                                'actual_value': 'N/A',
                                'actual_date': 'No data',
                                'forecast_2026': f"{round(forecast_2026, 1)}%" if forecast_2026 else None,
                                'display_value': f"{round(forecast_2026, 1)}%" if forecast_2026 else 'N/A',
                                'display_label': '2026F' if forecast_2026 else '',
                                'historical': [],
                                'trend': None,
                                'tooltip': tooltip
                            })
                    continue
                
                latest = db.query(DailyData).filter_by(
                    country_id=country.id,
                    metric_id=metric.id
                ).order_by(DailyData.date.desc()).first()
                
                if latest:
                    historical = db.query(DailyData).filter(
                        DailyData.country_id == country.id,
                        DailyData.metric_id == metric.id,
                        DailyData.date >= since_2020
                    ).order_by(DailyData.date).all()
                    historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 1)} for h in historical]
                    
                    is_positive_good = metric_code in ['gdp_growth', 'current_account']
                    if metric_code == 'budget_deficit':
                        is_positive_good = True
                    
                    arrow, desc, color = get_trend(country.id, metric.id, is_positive_good)
                    actual_value_str = f"{round(latest.value, 1)}%"
                    
                    if metric_code == 'gdp_growth':
                        name = 'GDP Growth'
                        date_str = latest.date.strftime('%b %Y')
                    elif metric_code == 'budget_deficit':
                        name = 'Budget Deficit (% GDP)'
                        date_str = latest.date.strftime('%Y')
                    elif metric_code == 'current_account':
                        name = 'Current Account (% GDP)'
                        date_str = latest.date.strftime('%b %Y')
                    else:
                        name = metric.name
                        date_str = latest.date.strftime('%b %Y')
                    
                    macro_data.append({
                        'name': name,
                        'actual_value': actual_value_str,
                        'actual_date': date_str,
                        'forecast_2026': f"{round(forecast_2026, 1)}%" if forecast_2026 else None,
                        'display_value': f"{round(forecast_2026, 1)}%" if forecast_2026 else actual_value_str,
                        'display_label': '2026F' if forecast_2026 else date_str,
                        'historical': historical_data,
                        'trend': {'arrow': arrow, 'description': desc, 'color': color},
                        'tooltip': tooltip
                    })
                else:
                    name_map = {
                        'gdp_growth': 'GDP Growth',
                        'budget_deficit': 'Budget Deficit (% GDP)',
                        'current_account': 'Current Account (% GDP)'
                    }
                    macro_data.append({
                        'name': name_map.get(metric_code, metric.name),
                        'actual_value': 'N/A',
                        'actual_date': 'No data',
                        'forecast_2026': f"{round(forecast_2026, 1)}%" if forecast_2026 else None,
                        'display_value': f"{round(forecast_2026, 1)}%" if forecast_2026 else 'N/A',
                        'display_label': '2026F' if forecast_2026 else '',
                        'historical': [],
                        'trend': None,
                        'tooltip': tooltip
                    })
            
            # MARKETS
            for metric_code in market_metrics:
                metric = metrics.get(metric_code)
                if not metric:
                    continue
                
                # Get tooltip for current expertise level
                if expertise_level == 'beginner':
                    tooltip = metric.tooltip_beginner
                elif expertise_level == 'expert':
                    tooltip = metric.tooltip_expert
                else:
                    tooltip = metric.tooltip_moderate
                
                latest = db.query(DailyData).filter_by(
                    country_id=country.id,
                    metric_id=metric.id
                ).order_by(DailyData.date.desc()).first()
                
                if latest:
                    # Get historical data for charts (last 1 year for markets)
                    one_year_ago = today - timedelta(days=365)
                    historical = db.query(DailyData).filter(
                        DailyData.country_id == country.id,
                        DailyData.metric_id == metric.id,
                        DailyData.date >= one_year_ago
                    ).order_by(DailyData.date).all()
                    
                    if metric_code == 'policy_rate':
                        arrow, desc, color = get_trend(country.id, metric.id, is_positive_good=True)
                        color = 'neutral'
                        value_str = f"{round(latest.value, 2)}%"
                        date_str = latest.date.strftime('%b %d')
                        rate_names = {
                            'USA': 'Federal Funds Rate',
                            'CAN': 'Bank of Canada Rate',
                            'GBR': 'Bank of England Rate',
                            'JPN': 'Bank of Japan Rate',
                            'DEU': 'ECB Rate',
                            'FRA': 'ECB Rate',
                            'ITA': 'ECB Rate',
                            'CHN': 'Policy Rate',
                            'IND': 'Policy Rate'
                        }
                        name = rate_names.get(country.code, 'Policy Interest Rate')
                        historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                    
                    elif metric_code == 'stock_index':
                        arrow, desc, color = get_trend(country.id, metric.id, is_positive_good=True)
                        year_start = date(today.year, 1, 1)
                        year_start_data = db.query(DailyData).filter_by(
                            country_id=country.id,
                            metric_id=metric.id
                        ).filter(DailyData.date >= year_start).order_by(DailyData.date.asc()).first()
                        
                        if year_start_data and year_start_data.value:
                            ytd_change = ((latest.value - year_start_data.value) / year_start_data.value) * 100
                            value_str = f"{ytd_change:+.1f}%"
                        else:
                            value_str = 'N/A'
                        
                        date_str = latest.date.strftime('%b %d')
                        index_names = {
                            'USA': 'S&P 500 YTD',
                            'CAN': 'S&P/TSX Composite YTD',
                            'GBR': 'FTSE 100 YTD',
                            'JPN': 'Nikkei 225 YTD',
                            'DEU': 'DAX YTD',
                            'FRA': 'CAC 40 YTD',
                            'ITA': 'FTSE MIB YTD',
                            'CHN': 'Shanghai Composite YTD',
                            'IND': 'BSE Sensex YTD'
                        }
                        name = index_names.get(country.code, 'Stock Market YTD')
                        historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                    
                    elif metric_code == 'bond_yield':
                        arrow, desc, color = get_trend(country.id, metric.id, is_positive_good=False)
                        value_str = f"{round(latest.value, 2)}%"
                        date_str = latest.date.strftime('%b %d')
                        bond_names = {
                            'USA': '10-Year Treasury',
                            'CAN': '10-Year Canada',
                            'GBR': '10-Year Gilt',
                            'JPN': '10-Year JGB',
                            'DEU': '10-Year Bund',
                            'FRA': '10-Year OAT',
                            'ITA': '10-Year BTP',
                            'CHN': '10-Year Bond',
                            'IND': '10-Year Bond'
                        }
                        name = bond_names.get(country.code, '10-Year Bond')
                        historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                    
                    elif metric_code == 'currency':
                        arrow, desc, color = get_trend(country.id, metric.id, is_positive_good=True)
                        color = 'neutral'
                        date_str = latest.date.strftime('%b %d')
                        
                        if country.code == 'USA':
                            name = 'US Dollar Index (USDX)'
                            value_str = f"{latest.value:.2f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                        elif country.code == 'GBR':
                            name = 'GBP/USD'
                            value_str = f"{latest.value:.4f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 4)} for h in historical]
                        elif country.code == 'JPN':
                            name = 'JPY/USD'
                            value_str = f"{latest.value:.2f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                        elif country.code == 'CAN':
                            name = 'CAD/USD'
                            value_str = f"{latest.value:.4f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 4)} for h in historical]
                        elif country.code in ['DEU', 'FRA', 'ITA']:
                            name = 'EUR/USD'
                            value_str = f"{latest.value:.4f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 4)} for h in historical]
                        elif country.code == 'CHN':
                            name = 'CNY/USD'
                            value_str = f"{latest.value:.4f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 4)} for h in historical]
                        elif country.code == 'IND':
                            name = 'INR/USD'
                            value_str = f"{latest.value:.2f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                        else:
                            name = 'FX Market'
                            value_str = f"{latest.value:.2f}"
                            historical_data = [{'date': h.date.strftime('%Y-%m-%d'), 'value': round(h.value, 2)} for h in historical]
                    
                    market_data.append({
                        'name': name,
                        'value': value_str,
                        'date': date_str,
                        'actual_value': value_str,
                        'actual_date': date_str,
                        'historical': historical_data,
                        'trend': {'arrow': arrow, 'description': desc, 'color': color},
                        'tooltip': tooltip
                    })
                else:
                    name_map = {
                        'policy_rate': 'Policy Interest Rate',
                        'stock_index': 'Stock Market YTD',
                        'bond_yield': '10-Year Bond',
                        'currency': 'FX Market'
                    }
                    market_data.append({
                        'name': name_map.get(metric_code, metric.name),
                        'value': 'N/A',
                        'date': '',
                        'actual_value': 'N/A',
                        'actual_date': 'No data',
                        'historical': [],
                        'trend': None,
                        'tooltip': tooltip
                    })
            
            cards_data.append({
                'country': {
                    'name': country.name,
                    'code': country.code,
                    'flag': country.flag_emoji
                },
                'card': {
                    'headline': headline,
                    'story': story,
                    'weather': card.weather_icon,
                    'date': card.date.strftime('%Y-%m-%d'),
                    'expertise_level': expertise_level
                },
                'macroeconomic': macro_data,
                'markets': market_data
            })
        
        return jsonify(cards_data)


@app.route('/api/expertise-levels')
def get_expertise_levels():
    """Get available expertise levels with descriptions"""
    return jsonify({
        'levels': [
            {
                'code': 'beginner',
                'name': 'Beginner',
                'description': 'Everyday language for curious learners',
                'audience': 'Curious laypeople, high school students'
            },
            {
                'code': 'moderate',
                'name': 'Moderate',
                'description': 'Standard economic terms and analysis',
                'audience': 'University undergrads, casual day traders'
            },
            {
                'code': 'expert',
                'name': 'Expert',
                'description': 'Technical analysis for professionals',
                'audience': 'Finance professionals, economists, postgrad students'
            }
        ],
        'default': 'moderate'
    })


@app.route('/api/health')
def health():
    """Health check endpoint"""
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=True)
