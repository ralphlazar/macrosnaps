"""
Updated Database Schema for MacroSnaps with Multi-Level Expertise Support
Stores 3 versions of all story content: BEGINNER, MODERATE, EXPERT
"""
from sqlalchemy import Column, Integer, String, Float, Date, ForeignKey, Text, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class ExpertiseLevel(enum.Enum):
    """User expertise levels"""
    BEGINNER = "beginner"    # Curious laypeople, high school students
    MODERATE = "moderate"    # University undergrads, casual day traders
    EXPERT = "expert"        # Finance professionals, economists, postgrad students


class Country(Base):
    """Country model"""
    __tablename__ = 'countries'
    
    id = Column(Integer, primary_key=True)
    code = Column(String(3), unique=True, nullable=False)  # USA, CAN, GBR, etc.
    name = Column(String(100), nullable=False)  # United States, Canada, etc.
    flag_emoji = Column(String(10))
    display_order = Column(Integer, default=0)
    
    cards = relationship('Card', back_populates='country')
    daily_data = relationship('DailyData', back_populates='country')


class Metric(Base):
    """Economic metric model"""
    __tablename__ = 'metrics'
    
    id = Column(Integer, primary_key=True)
    code = Column(String(50), unique=True, nullable=False)  # gdp_growth, inflation, etc.
    name = Column(String(100), nullable=False)
    category = Column(String(50))  # 'macroeconomic' or 'market'
    
    # Tooltips for each expertise level
    tooltip_beginner = Column(Text)
    tooltip_moderate = Column(Text)
    tooltip_expert = Column(Text)
    
    daily_data = relationship('DailyData', back_populates='metric')


class Card(Base):
    """Daily economic card with multi-level stories"""
    __tablename__ = 'cards'
    
    id = Column(Integer, primary_key=True)
    country_id = Column(Integer, ForeignKey('countries.id'), nullable=False)
    date = Column(Date, nullable=False)
    
    # Headlines for each expertise level
    headline_beginner = Column(String(200))
    headline_moderate = Column(String(200))
    headline_expert = Column(String(200))
    
    # Stories (3 bullets each) for each expertise level
    story_beginner = Column(Text)      # Newline-separated bullets
    story_moderate = Column(Text)      # Newline-separated bullets
    story_expert = Column(Text)        # Newline-separated bullets
    
    # Weather icon (same for all levels)
    weather_icon = Column(String(10))
    
    country = relationship('Country', back_populates='cards')
    
    # Unique constraint: one card per country per day
    __table_args__ = (
        {'sqlite_autoincrement': True},
    )


class DailyData(Base):
    """Daily metric values"""
    __tablename__ = 'daily_data'
    
    id = Column(Integer, primary_key=True)
    country_id = Column(Integer, ForeignKey('countries.id'), nullable=False)
    metric_id = Column(Integer, ForeignKey('metrics.id'), nullable=False)
    date = Column(Date, nullable=False)
    value = Column(Float, nullable=False)
    
    country = relationship('Country', back_populates='daily_data')
    metric = relationship('Metric', back_populates='daily_data')
    
    __table_args__ = (
        {'sqlite_autoincrement': True},
    )


# Example of how to create tooltip content for metrics
METRIC_TOOLTIPS = {
    'gdp_growth': {
        'beginner': 'GDP (Gross Domestic Product) measures the total value of everything a country produces. When it grows, the economy is expanding and creating more jobs and wealth.',
        'moderate': 'GDP Growth shows how fast the economy is expanding. Positive growth indicates economic expansion, while negative growth signals recession. Central banks monitor this closely for policy decisions.',
        'expert': 'GDP Growth rate (annualized quarterly change) measures aggregate output expansion. Decomposition across consumption, investment, government spending, and net exports reveals underlying drivers. Potential GDP comparison indicates output gap.'
    },
    'inflation': {
        'beginner': 'Inflation means prices are going up. When inflation is high, your money doesn\'t buy as much. Central banks try to keep it around 2% per year.',
        'moderate': 'Inflation (CPI) measures the rate at which prices for goods and services rise. Central banks target ~2% as healthy. High inflation erodes purchasing power; low inflation may signal weak demand.',
        'expert': 'CPI inflation captures headline price movements. Core CPI (ex-food and energy) reveals underlying trends. PCE preferred by Fed. Decompose into goods vs services, shelter, and supercore. Monitor breakeven rates and inflation expectations.'
    },
    'policy_rate': {
        'beginner': 'This is the interest rate set by the country\'s central bank. When it\'s higher, borrowing costs more, which can slow down inflation. When it\'s lower, it\'s cheaper to borrow money.',
        'moderate': 'The policy rate is the central bank\'s main tool for managing the economy. Higher rates fight inflation by making borrowing expensive. Lower rates stimulate growth by making credit cheap.',
        'expert': 'Policy rate transmission occurs through credit channels, asset prices, and expectations. Forward guidance and terminal rate projections shape yield curves. Real rates (nominal minus inflation expectations) drive investment decisions.'
    },
    'stock_index': {
        'beginner': 'Stock markets show how well companies are doing. When stocks go up, it usually means investors are optimistic about the economy. When they fall, investors are worried.',
        'moderate': 'Stock market indices track overall market performance. YTD (year-to-date) returns reflect investor sentiment on economic growth, corporate earnings, and monetary policy. Correlates with economic confidence.',
        'expert': 'Equity indices reflect discounted future cash flows and risk premiums. Decompose returns into earnings growth, multiple expansion/compression, and dividend yield. Monitor sector rotation, volatility (VIX), and correlation with macro factors.'
    },
    'bond_yield': {
        'beginner': 'Bond yields show what interest rate the government pays to borrow money. When yields rise, it costs more for governments (and businesses) to borrow.',
        'moderate': '10-year government bond yields reflect market expectations for growth, inflation, and monetary policy. Rising yields indicate expectations of higher rates or inflation. Yields influence borrowing costs across the economy.',
        'expert': '10-year sovereign yields embed expectations for policy path, term premium, and inflation risk. Yield curve (2s10s) signals recession risk when inverted. Real yields (TIPS) isolate growth expectations. Monitor OIS spreads and duration risk.'
    },
    'currency': {
        'beginner': 'Currency exchange rates show how strong a country\'s money is compared to others. A stronger currency makes imports cheaper but can hurt exports.',
        'moderate': 'Exchange rates reflect relative economic strength, interest rate differentials, and trade balances. Stronger currencies reduce import costs but make exports less competitive. Central banks may intervene to manage volatility.',
        'expert': 'FX rates determined by interest rate differentials (covered interest parity), terms of trade, capital flows, and relative monetary policy stances. Monitor real effective exchange rates, carry trade dynamics, and currency interventions.'
    },
    'budget_deficit': {
        'beginner': 'This shows how much more money the government spends than it collects in taxes. A bigger deficit means more government borrowing. As a percentage of GDP, it shows if the deficit is growing faster than the economy.',
        'moderate': 'Budget deficit (% of GDP) measures fiscal position. Persistent deficits increase national debt. Deficits can stimulate growth short-term but may crowd out private investment and raise borrowing costs long-term.',
        'expert': 'Fiscal deficit as % of GDP indicates sustainability of debt trajectory. Decompose into cyclical (automatic stabilizers) and structural components. Monitor primary balance, debt-to-GDP ratio, and sovereign risk premiums. Assess fiscal multipliers and crowding out effects.'
    },
    'current_account': {
        'beginner': 'This measures if a country is selling more to other countries than it\'s buying (surplus) or buying more than it\'s selling (deficit). It includes trade in goods, services, and investment income.',
        'moderate': 'Current account (% of GDP) reflects net trade in goods/services plus investment income. Deficits mean more imports than exports, requiring foreign financing. Persistent imbalances can signal competitiveness issues or strong domestic demand.',
        'expert': 'Current account decomposed into trade balance, net primary income (investment returns), and secondary income (transfers). Persistent deficits require capital inflows, increasing external vulnerability. Monitor with financial account, FX reserves, and external debt sustainability.'
    }
}
