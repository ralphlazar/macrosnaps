"""
Database models for Macro Snaps
"""
from sqlalchemy import Column, Integer, String, Text, Float, Date, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class Country(Base):
    """M9 countries"""
    __tablename__ = 'countries'
    
    id = Column(Integer, primary_key=True)
    code = Column(String(3), unique=True, nullable=False)  # USA, CHN, JPN, etc.
    name = Column(String(50), nullable=False)
    flag_emoji = Column(String(10), nullable=False)
    display_order = Column(Integer, nullable=False)  # 1-9 for M9
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    daily_data = relationship('DailyData', back_populates='country', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<Country {self.code}: {self.name}>"


class Metric(Base):
    """8 economic metrics per country"""
    __tablename__ = 'metrics'
    
    id = Column(Integer, primary_key=True)
    code = Column(String(20), unique=True, nullable=False)  # gdp_growth, inflation, etc.
    name = Column(String(100), nullable=False)
    unit = Column(String(20), nullable=False)  # %, USD, etc.
    display_order = Column(Integer, nullable=False)  # 1-8
    created_at = Column(DateTime, default=datetime.utcnow)
    
    
    # Tooltips for each expertise level
    tooltip_beginner = Column(Text)
    tooltip_moderate = Column(Text)
    tooltip_expert = Column(Text)
    
        # Relationships
    daily_data = relationship('DailyData', back_populates='metric', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<Metric {self.code}: {self.name}>"


class DailyData(Base):
    """Daily economic data points (72 per day: 9 countries × 8 metrics)"""
    __tablename__ = 'daily_data'
    
    id = Column(Integer, primary_key=True)
    country_id = Column(Integer, ForeignKey('countries.id'), nullable=False)
    metric_id = Column(Integer, ForeignKey('metrics.id'), nullable=False)
    date = Column(Date, nullable=False)
    value = Column(Float, nullable=True)  # Nullable for missing data
    source = Column(String(50), nullable=True)  # IMF, FRED, Yahoo, etc.
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    country = relationship('Country', back_populates='daily_data')
    metric = relationship('Metric', back_populates='daily_data')
    
    # Unique constraint: one value per country/metric/date
    __table_args__ = (
        UniqueConstraint('country_id', 'metric_id', 'date', name='uix_country_metric_date'),
    )
    
    def __repr__(self):
        return f"<DailyData {self.country.code}/{self.metric.code}/{self.date}: {self.value}>"


class Card(Base):
    """Generated daily cards with multi-level expertise content"""
    __tablename__ = 'cards'
    
    id = Column(Integer, primary_key=True)
    country_id = Column(Integer, ForeignKey('countries.id'), nullable=False)
    date = Column(Date, nullable=False)
    
    # Multi-level headlines (one for each expertise level)
    headline_beginner = Column(String(200))
    headline_moderate = Column(String(200))
    headline_expert = Column(String(200))
    
    # Multi-level stories (one for each expertise level)
    story_beginner = Column(Text)
    story_moderate = Column(Text)
    story_expert = Column(Text)
    
    # Weather icon (same for all levels)
    weather_icon = Column(String(20))  # ☀️, ⛅, ☁️, 🌧️, ⛈️
    
    # AI generation metadata
    ai_generated = Column(DateTime, nullable=True)
    user_edited = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    country = relationship('Country')
    
    # Unique constraint: one card per country per date
    __table_args__ = (
        UniqueConstraint('country_id', 'date', name='uix_country_date'),
    )
    
    def __repr__(self):
        return f"<Card {self.country.code}/{self.date}>"