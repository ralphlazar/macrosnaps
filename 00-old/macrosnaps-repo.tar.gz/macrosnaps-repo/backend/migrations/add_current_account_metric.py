"""
Add current_account metric to database
"""
from backend.utils.database import get_db
from backend.models.schema import Metric


def add_current_account_metric():
    """Add current account balance metric"""
    with get_db() as db:
        # Check if metric already exists
        existing = db.query(Metric).filter_by(code='current_account').first()
        if existing:
            print("✓ current_account metric already exists")
            return
        
        # Add new metric (code shortened to fit 20 char limit)
        metric = Metric(
            code='current_account',
            name='Current Account Balance',
            unit='% of GDP',
            display_order=8  # After budget_deficit (7)
        )
        db.add(metric)
        db.commit()
        print("✓ Added current_account metric")


if __name__ == '__main__':
    print("Adding current_account metric to database...")
    add_current_account_metric()
    print("\n✓ Migration complete!")
