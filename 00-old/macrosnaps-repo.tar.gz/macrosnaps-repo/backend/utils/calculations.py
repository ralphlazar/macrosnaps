"""
Economic calculations and transformations
"""
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData
from datetime import date, timedelta


def calculate_yoy_inflation(country_code):
    """
    Calculate year-over-year inflation rate from CPI index
    
    Returns:
        (inflation_rate, as_of_date) or (None, None)
    """
    with get_db() as db:
        country = db.query(Country).filter_by(code=country_code).first()
        metric = db.query(Metric).filter_by(code='inflation').first()
        
        if not country or not metric:
            return None, None
        
        # Get latest CPI
        latest = db.query(DailyData).filter_by(
            country_id=country.id,
            metric_id=metric.id
        ).order_by(DailyData.date.desc()).first()
        
        if not latest:
            return None, None
        
        # Get CPI from 12 months ago
        year_ago_date = date(latest.date.year - 1, latest.date.month, latest.date.day)
        
        # Find closest match within 45 days
        year_ago = db.query(DailyData).filter_by(
            country_id=country.id,
            metric_id=metric.id
        ).filter(
            DailyData.date >= year_ago_date - timedelta(days=45),
            DailyData.date <= year_ago_date + timedelta(days=45)
        ).order_by(DailyData.date.desc()).first()
        
        if not year_ago:
            return None, None
        
        # Calculate YoY inflation rate
        inflation_rate = ((latest.value - year_ago.value) / year_ago.value) * 100
        
        return round(inflation_rate, 1), latest.date


def calculate_historical_yoy_inflation(country_code, since_date=None):
    """
    Calculate year-over-year inflation rate for ALL historical CPI data points
    
    Args:
        country_code: Country code (e.g., 'USA')
        since_date: Optional date to start from (default: all data)
    
    Returns:
        List of dicts: [{'date': 'YYYY-MM-DD', 'value': inflation_rate}, ...]
    """
    with get_db() as db:
        country = db.query(Country).filter_by(code=country_code).first()
        metric = db.query(Metric).filter_by(code='inflation').first()
        
        if not country or not metric:
            return []
        
        # Get all CPI data
        query = db.query(DailyData).filter_by(
            country_id=country.id,
            metric_id=metric.id
        )
        
        if since_date:
            query = query.filter(DailyData.date >= since_date)
        
        all_data = query.order_by(DailyData.date).all()
        
        if len(all_data) < 2:
            return []
        
        # Create a dict for fast lookup by date
        cpi_by_date = {d.date: d.value for d in all_data}
        
        historical_inflation = []
        
        for data_point in all_data:
            current_date = data_point.date
            current_cpi = data_point.value
            
            # Calculate date from 12 months ago
            try:
                year_ago_date = date(current_date.year - 1, current_date.month, current_date.day)
            except ValueError:
                # Handle Feb 29 in leap year
                year_ago_date = date(current_date.year - 1, current_date.month, 28)
            
            # Find CPI from approximately 12 months ago (within 45 days)
            year_ago_cpi = None
            for days_offset in range(0, 46):
                # Try exact date first, then go backwards, then forwards
                for offset in [0, -days_offset, days_offset]:
                    check_date = year_ago_date + timedelta(days=offset)
                    if check_date in cpi_by_date:
                        year_ago_cpi = cpi_by_date[check_date]
                        break
                if year_ago_cpi is not None:
                    break
            
            # Only calculate if we found a year-ago value
            if year_ago_cpi is not None and year_ago_cpi != 0:
                yoy_inflation = ((current_cpi - year_ago_cpi) / year_ago_cpi) * 100
                historical_inflation.append({
                    'date': current_date.strftime('%Y-%m-%d'),
                    'value': round(yoy_inflation, 1)
                })
        
        return historical_inflation


if __name__ == '__main__':
    # Test the calculation
    rate, as_of = calculate_yoy_inflation('USA')
    if rate:
        print(f"USA Inflation Rate: {rate}% YoY (as of {as_of})")
    else:
        print("Could not calculate inflation rate")
    
    # Test historical calculation
    from datetime import date
    historical = calculate_historical_yoy_inflation('USA', since_date=date(2020, 1, 1))
    if historical:
        print(f"\nHistorical inflation data points: {len(historical)}")
        print(f"First: {historical[0]}")
        print(f"Last: {historical[-1]}")