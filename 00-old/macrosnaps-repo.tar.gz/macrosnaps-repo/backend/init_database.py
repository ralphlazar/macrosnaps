"""
Initialize database with M9 countries and 8 metrics
"""
from backend.utils.database import init_db, get_db
from backend.models.schema import Country, Metric
from datetime import datetime


def seed_countries():
    """Insert M9 countries"""
    countries_data = [
        {'code': 'USA', 'name': 'United States', 'flag_emoji': '🇺🇸', 'display_order': 1},
        {'code': 'CHN', 'name': 'China', 'flag_emoji': '🇨🇳', 'display_order': 2},
        {'code': 'JPN', 'name': 'Japan', 'flag_emoji': '🇯🇵', 'display_order': 3},
        {'code': 'DEU', 'name': 'Germany', 'flag_emoji': '🇩🇪', 'display_order': 4},
        {'code': 'IND', 'name': 'India', 'flag_emoji': '🇮🇳', 'display_order': 5},
        {'code': 'GBR', 'name': 'United Kingdom', 'flag_emoji': '🇬🇧', 'display_order': 6},
        {'code': 'FRA', 'name': 'France', 'flag_emoji': '🇫🇷', 'display_order': 7},
        {'code': 'ITA', 'name': 'Italy', 'flag_emoji': '🇮🇹', 'display_order': 8},
        {'code': 'CAN', 'name': 'Canada', 'flag_emoji': '🇨🇦', 'display_order': 9},
    ]
    
    with get_db() as db:
        for data in countries_data:
            country = Country(**data)
            db.add(country)
        print(f"✓ Inserted {len(countries_data)} countries")


def seed_metrics():
    """Insert 8 economic metrics"""
    metrics_data = [
        {'code': 'gdp_growth', 'name': 'GDP Growth Rate', 'unit': '%', 'display_order': 1},
        {'code': 'inflation', 'name': 'Inflation Rate (CPI)', 'unit': '%', 'display_order': 2},
        {'code': 'unemployment', 'name': 'Unemployment Rate', 'unit': '%', 'display_order': 3},
        {'code': 'budget_deficit', 'name': 'Budget Deficit', 'unit': '% of GDP', 'display_order': 4},
        {'code': 'policy_rate', 'name': 'Central Bank Policy Rate', 'unit': '%', 'display_order': 5},
        {'code': 'stock_index', 'name': 'Stock Market Index', 'unit': 'points', 'display_order': 6},
        {'code': 'bond_yield', 'name': '10-Year Bond Yield', 'unit': '%', 'display_order': 7},
        {'code': 'currency', 'name': 'Currency vs USD', 'unit': 'rate', 'display_order': 8},
    ]
    
    with get_db() as db:
        for data in metrics_data:
            metric = Metric(**data)
            db.add(metric)
        print(f"✓ Inserted {len(metrics_data)} metrics")


if __name__ == '__main__':
    print("Initializing Macro Snaps database...")
    init_db()
    seed_countries()
    seed_metrics()
    print("\n✓ Database initialization complete!")
