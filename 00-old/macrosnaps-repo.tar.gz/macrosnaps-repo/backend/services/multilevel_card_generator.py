"""
Multi-Level Card Generator for MacroSnaps
Generates cards with content for all 3 expertise levels
"""
from datetime import date
from backend.utils.database import get_db
from backend.models.schema import Country, Card
from backend.services.multilevel_claude_service import MultiLevelClaudeGenerator
import os


class MultiLevelCardGenerator:
    """Generate economic summary cards with multi-level content"""
    
    def __init__(self, use_ai: bool = True):
        """
        Initialize card generator
        Args:
            use_ai: Whether to use Claude AI for story generation (default True)
        """
        self.use_ai = use_ai
        if use_ai:
            self.ai_generator = MultiLevelClaudeGenerator()
        else:
            self.ai_generator = None
    
    def generate_all_cards(self, target_date: date = None) -> int:
        """
        Generate cards for all countries with multi-level content
        
        Args:
            target_date: Date for the cards (defaults to today)
        
        Returns:
            Number of cards generated
        """
        if target_date is None:
            target_date = date.today()
        
        with get_db() as db:
            countries = db.query(Country).order_by(Country.display_order).all()
            cards_generated = 0
            
            for country in countries:
                try:
                    card = self.generate_card_for_country(country, target_date, db)
                    if card:
                        cards_generated += 1
                        print(f"✓ Generated multi-level card for {country.name}")
                except Exception as e:
                    print(f"✗ Error generating card for {country.name}: {e}")
            
            return cards_generated
    
    def generate_card_for_country(self, country, target_date: date, db) -> Card:
        """
        Generate a card with content for all 3 expertise levels
        
        Args:
            country: Country model instance
            target_date: Date for the card
            db: Database session
        
        Returns:
            Card model instance with multi-level content
        """
        # Check if card already exists
        existing_card = db.query(Card).filter_by(
            country_id=country.id,
            date=target_date
        ).first()
        
        if existing_card:
            print(f"Card already exists for {country.name} on {target_date}")
            return existing_card
        
        # Gather economic data
        economic_data = self._gather_economic_data(country, db)
        
        # Generate multi-level content using AI or fallback
        if self.use_ai and self.ai_generator:
            # Generate stories for all 3 levels
            stories = self.ai_generator.generate_multi_level_stories(
                country_name=country.name,
                country_code=country.code,
                economic_data=economic_data
            )
            
            # Format stories (convert list to newline-separated string)
            story_beginner = "\n".join([f"• {bullet}" for bullet in stories.beginner])
            story_moderate = "\n".join([f"• {bullet}" for bullet in stories.moderate])
            story_expert = "\n".join([f"• {bullet}" for bullet in stories.expert])
            
            # Generate headlines for all 3 levels
            headlines = self.ai_generator.generate_multi_level_headlines(
                country_name=country.name,
                economic_data=economic_data
            )
            
            headline_beginner = headlines.beginner
            headline_moderate = headlines.moderate
            headline_expert = headlines.expert
            
            # Generate weather icon (same for all levels)
            weather_icon = self.ai_generator.generate_weather_icon(economic_data)
        else:
            # Fallback to simple generation
            story_beginner = self._generate_fallback_story(country.name, economic_data, 'beginner')
            story_moderate = self._generate_fallback_story(country.name, economic_data, 'moderate')
            story_expert = self._generate_fallback_story(country.name, economic_data, 'expert')
            
            headline_beginner = f"{country.name} Economy Update"
            headline_moderate = f"{country.name} Economic Snapshot"
            headline_expert = f"{country.name} Macro Overview"
            
            weather_icon = "☁️"
        
        # Create and save the card
        card = Card(
            country_id=country.id,
            date=target_date,
            headline_beginner=headline_beginner,
            headline_moderate=headline_moderate,
            headline_expert=headline_expert,
            story_beginner=story_beginner,
            story_moderate=story_moderate,
            story_expert=story_expert,
            weather_icon=weather_icon
        )
        
        db.add(card)
        db.commit()
        db.refresh(card)
        
        return card
    
    def _gather_economic_data(self, country, db) -> dict:
        """Gather all economic data for a country"""
        from backend.models.schema import Metric, DailyData
        from backend.utils.calculations import calculate_yoy_inflation
        
        macro_metrics = ['gdp_growth', 'inflation', 'budget_deficit', 'current_account']
        market_metrics = ['policy_rate', 'stock_index', 'bond_yield', 'currency']
        
        metrics = {m.code: m for m in db.query(Metric).all()}
        
        macro_data = []
        market_data = []
        
        # Get macroeconomic data
        for metric_code in macro_metrics:
            metric = metrics.get(metric_code)
            if not metric:
                continue
            
            if metric_code == 'inflation':
                # Special handling for inflation
                if country.code == 'CAN':
                    latest = db.query(DailyData).filter_by(
                        country_id=country.id,
                        metric_id=metric.id
                    ).order_by(DailyData.date.desc()).first()
                    
                    if latest:
                        macro_data.append({
                            'name': 'Inflation (CPI)',
                            'display_value': f"{round(latest.value, 1)}%",
                            'display_label': latest.date.strftime('%b %Y'),
                            'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good=False)
                        })
                else:
                    rate, as_of = calculate_yoy_inflation(country.code)
                    if rate is not None:
                        macro_data.append({
                            'name': 'Inflation (CPI)',
                            'display_value': f"{rate}%",
                            'display_label': as_of.strftime('%b %Y'),
                            'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good=False)
                        })
            else:
                latest = db.query(DailyData).filter_by(
                    country_id=country.id,
                    metric_id=metric.id
                ).order_by(DailyData.date.desc()).first()
                
                if latest:
                    is_positive_good = metric_code in ['gdp_growth', 'current_account', 'budget_deficit']
                    
                    name_map = {
                        'gdp_growth': 'GDP Growth',
                        'budget_deficit': 'Budget Deficit (% GDP)',
                        'current_account': 'Current Account (% GDP)'
                    }
                    
                    macro_data.append({
                        'name': name_map.get(metric_code, metric.name),
                        'display_value': f"{round(latest.value, 1)}%",
                        'display_label': latest.date.strftime('%b %Y'),
                        'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good)
                    })
        
        # Get market data
        for metric_code in market_metrics:
            metric = metrics.get(metric_code)
            if not metric:
                continue
            
            latest = db.query(DailyData).filter_by(
                country_id=country.id,
                metric_id=metric.id
            ).order_by(DailyData.date.desc()).first()
            
            if latest:
                if metric_code == 'policy_rate':
                    name_map = {
                        'USA': 'Federal Funds Rate',
                        'CAN': 'Bank of Canada Rate',
                        'GBR': 'Bank of England Rate',
                        'JPN': 'Bank of Japan Rate'
                    }
                    market_data.append({
                        'name': name_map.get(country.code, 'Policy Rate'),
                        'value': f"{round(latest.value, 2)}%",
                        'date': latest.date.strftime('%b %d'),
                        'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good=True)
                    })
                
                elif metric_code == 'stock_index':
                    # Calculate YTD change
                    year_start = date(latest.date.year, 1, 1)
                    year_start_data = db.query(DailyData).filter_by(
                        country_id=country.id,
                        metric_id=metric.id
                    ).filter(DailyData.date >= year_start).order_by(DailyData.date.asc()).first()
                    
                    if year_start_data and year_start_data.value:
                        ytd_change = ((latest.value - year_start_data.value) / year_start_data.value) * 100
                        value_str = f"{ytd_change:+.1f}%"
                    else:
                        value_str = 'N/A'
                    
                    index_names = {
                        'USA': 'S&P 500 YTD',
                        'CAN': 'S&P/TSX Composite YTD'
                    }
                    
                    market_data.append({
                        'name': index_names.get(country.code, 'Stock Market YTD'),
                        'value': value_str,
                        'date': latest.date.strftime('%b %d'),
                        'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good=True)
                    })
                
                elif metric_code == 'bond_yield':
                    bond_names = {
                        'USA': '10-Year Treasury',
                        'CAN': '10-Year Canada'
                    }
                    market_data.append({
                        'name': bond_names.get(country.code, '10-Year Bond'),
                        'value': f"{round(latest.value, 2)}%",
                        'date': latest.date.strftime('%b %d'),
                        'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good=False)
                    })
                
                elif metric_code == 'currency':
                    if country.code == 'USA':
                        name = 'US Dollar Index'
                        value = f"{latest.value:.2f}"
                    elif country.code == 'CAN':
                        name = 'CAD/USD'
                        value = f"{latest.value:.4f}"
                    else:
                        name = 'FX Rate'
                        value = f"{latest.value:.2f}"
                    
                    market_data.append({
                        'name': name,
                        'value': value,
                        'date': latest.date.strftime('%b %d'),
                        'trend': self._calculate_trend(country.id, metric.id, db, is_positive_good=True)
                    })
        
        return {
            'macroeconomic': macro_data,
            'markets': market_data
        }
    
    def _calculate_trend(self, country_id, metric_id, db, is_positive_good=True) -> dict:
        """Calculate trend from recent data points"""
        from backend.models.schema import DailyData
        
        recent_data = db.query(DailyData).filter_by(
            country_id=country_id,
            metric_id=metric_id
        ).order_by(DailyData.date.desc()).limit(3).all()
        
        if len(recent_data) < 2:
            return {'arrow': '→', 'description': 'stable', 'color': 'neutral'}
        
        latest = recent_data[0].value
        previous = recent_data[-1].value
        
        change = latest - previous
        pct_change = (change / abs(previous)) * 100 if previous != 0 else 0
        
        if abs(pct_change) < 0.1:
            return {'arrow': '→', 'description': 'stable', 'color': 'neutral'}
        elif change > 0:
            color = 'good' if is_positive_good else 'bad'
            return {'arrow': '↗', 'description': 'rising', 'color': color}
        else:
            color = 'bad' if is_positive_good else 'good'
            return {'arrow': '↘', 'description': 'falling', 'color': color}
    
    def _generate_fallback_story(self, country_name: str, economic_data: dict, level: str) -> str:
        """Generate simple fallback story for a specific expertise level"""
        bullets = []
        
        macro = economic_data.get('macroeconomic', [])
        markets = economic_data.get('markets', [])
        
        # Adjust language based on level
        if level == 'beginner':
            for metric in macro[:2]:
                name = metric.get('name', '')
                value = metric.get('display_value', '')
                bullets.append(f"• {name} is at {value}")
            if markets:
                metric = markets[0]
                name = metric.get('name', '')
                value = metric.get('value', '')
                bullets.append(f"• {name} is {value}")
        
        elif level == 'moderate':
            for metric in macro[:2]:
                name = metric.get('name', '')
                value = metric.get('display_value', '')
                bullets.append(f"• {name}: {value}")
            if markets:
                metric = markets[0]
                name = metric.get('name', '')
                value = metric.get('value', '')
                bullets.append(f"• {name}: {value}")
        
        else:  # expert
            for metric in macro[:2]:
                name = metric.get('name', '')
                value = metric.get('display_value', '')
                bullets.append(f"• {name} {value}")
            if markets:
                metric = markets[0]
                name = metric.get('name', '')
                value = metric.get('value', '')
                bullets.append(f"• {name} {value}")
        
        return "\n".join(bullets) if bullets else f"• Economic data for {country_name}"


def main():
    """Main execution function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate MacroSnaps multi-level cards')
    parser.add_argument('--no-ai', action='store_true', help='Generate without AI (use fallback)')
    parser.add_argument('--country', type=str, help='Generate for specific country code (e.g., USA)')
    
    args = parser.parse_args()
    
    generator = MultiLevelCardGenerator(use_ai=not args.no_ai)
    
    if args.country:
        with get_db() as db:
            from backend.models.schema import Country
            country = db.query(Country).filter_by(code=args.country.upper()).first()
            if country:
                card = generator.generate_card_for_country(country, date.today(), db)
                print(f"\n{'='*60}")
                print(f"Multi-Level Card for {country.name}")
                print(f"{'='*60}")
                
                print(f"\nBEGINNER LEVEL:")
                print(f"Headline: {card.headline_beginner}")
                print(f"Story:\n{card.story_beginner}")
                
                print(f"\nMODERATE LEVEL:")
                print(f"Headline: {card.headline_moderate}")
                print(f"Story:\n{card.story_moderate}")
                
                print(f"\nEXPERT LEVEL:")
                print(f"Headline: {card.headline_expert}")
                print(f"Story:\n{card.story_expert}")
                
                print(f"\nWeather: {card.weather_icon}")
                print(f"{'='*60}\n")
            else:
                print(f"Country '{args.country}' not found")
    else:
        print(f"Generating multi-level cards for all countries...")
        count = generator.generate_all_cards()
        print(f"\n✓ Generated {count} multi-level cards successfully")


if __name__ == "__main__":
    main()
