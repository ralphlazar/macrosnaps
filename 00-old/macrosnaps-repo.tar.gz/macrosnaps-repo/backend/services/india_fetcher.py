"""
Fetch India economic data from FRED, Yahoo Finance, and IMF WEO
Note: India data availability in FRED is limited (only 5/7 metrics available)
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for India
# Note: Unemployment and bond yield not reliably available in FRED
INDIA_SERIES = {
    'gdp_growth': 'NAEXKP01INQ657S',
    'inflation': 'INDCPIALLMINMEI',
    # 'unemployment': Not available
    'policy_rate': 'IRSTCI01INM156N',
    # 'bond_yield': Not available
    'currency': 'DEXINUS',
    'current_account': 'INDB6BLTT02STSAQ',
}

INDIA_STOCK_SYMBOL = '^BSESN'


def fetch_india_data(days_back=730):
    """
    Fetch all India economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching India data from FRED and IMF WEO...")
    print("  Note: Only 6/9 metrics available (unemployment, bond yield missing)")
    results = {}
    
    for metric_code, series_id in INDIA_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('IND')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_india_stock(days_back=30):
    """
    Fetch BSE Sensex data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching BSE Sensex from Yahoo Finance...")
    observations = fetch_yahoo_stock(INDIA_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing India Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_india_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_india_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"BSE Sensex: {latest[1]:.2f} (as of {latest[0]})")