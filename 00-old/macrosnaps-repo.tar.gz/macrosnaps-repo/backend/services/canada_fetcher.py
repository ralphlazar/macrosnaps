"""
Fetch Canada economic data from FRED, Yahoo Finance, and IMF WEO
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for Canada
CANADA_SERIES = {
    'gdp_growth': 'NAEXKP01CAQ657S',
    'inflation': 'CPALTT01CAM659N',
    'unemployment': 'LRHUTTTTCAM156S',
    'policy_rate': 'IRSTCI01CAM156N',
    'bond_yield': 'IRLTLT01CAM156N',
    'currency': 'DEXCAUS',
    'current_account': 'CANB6BLTT02STSAQ',
}

CANADA_STOCK_SYMBOL = '^GSPTSE'


def fetch_canada_data(days_back=730):
    """
    Fetch all Canada economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching Canada data from FRED and IMF WEO...")
    results = {}
    
    for metric_code, series_id in CANADA_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('CAN')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_canada_stock(days_back=30):
    """
    Fetch S&P/TSX Composite data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching S&P/TSX Composite from Yahoo Finance...")
    observations = fetch_yahoo_stock(CANADA_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing Canada Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_canada_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_canada_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"S&P/TSX Composite: {latest[1]:.2f} (as of {latest[0]})")