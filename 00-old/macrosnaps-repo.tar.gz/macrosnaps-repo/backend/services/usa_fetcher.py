"""
Fetch USA economic data from FRED, Yahoo Finance, and IMF WEO
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for USA
USA_SERIES = {
    'gdp_growth': 'A191RL1Q225SBEA',
    'inflation': 'CPIAUCSL',
    'unemployment': 'UNRATE',
    'policy_rate': 'FEDFUNDS',
    'bond_yield': 'DGS10',
    'currency': 'DTWEXBGS',
    'current_account': 'USAB6BLTT02STSAQ',
}

USA_STOCK_SYMBOL = '^GSPC'


def fetch_usa_data(days_back=730):
    """
    Fetch all USA economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching USA data from FRED and IMF WEO...")
    results = {}
    
    # Fetch FRED data
    for metric_code, series_id in USA_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('USA')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_usa_stock(days_back=30):
    """
    Fetch S&P 500 data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching S&P 500 from Yahoo Finance...")
    observations = fetch_yahoo_stock(USA_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing USA Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_usa_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_usa_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"S&P 500: {latest[1]:.2f} (as of {latest[0]})")
