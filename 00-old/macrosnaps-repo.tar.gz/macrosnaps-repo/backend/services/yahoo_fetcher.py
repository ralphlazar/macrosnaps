"""
Yahoo Finance data fetcher for stock indices and currencies
"""
import yfinance as yf
from datetime import datetime, timedelta


def fetch_yahoo_stock(symbol, days_back=30):
    """
    Fetch stock/index data from Yahoo Finance using yfinance
    
    Args:
        symbol: Yahoo Finance symbol (e.g., ^GSPC for S&P 500)
        days_back: Number of days of history
    
    Returns:
        List of (date, close_price) tuples
    """
    try:
        # Download data
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        ticker = yf.Ticker(symbol)
        hist = ticker.history(start=start_date, end=end_date)
        
        observations = []
        for date, row in hist.iterrows():
            close_price = row['Close']
            date_obj = date.date()
            observations.append((date_obj, close_price))
        
        return observations
    
    except Exception as e:
        print(f"Error fetching {symbol}: {e}")
        return []


# Stock indices for M9 countries
M9_STOCK_INDICES = {
    'USA': '^GSPC',      # S&P 500
    'CHN': '000001.SS',  # Shanghai Composite
    'JPN': '^N225',      # Nikkei 225
    'DEU': '^GDAXI',     # DAX
    'IND': '^BSESN',     # BSE Sensex
    'GBR': '^FTSE',      # FTSE 100
    'FRA': '^FCHI',      # CAC 40
    'ITA': 'FTSEMIB.MI', # FTSE MIB
    'CAN': '^GSPTSE',    # S&P/TSX Composite
}


def fetch_usa_stock(days_back=30):
    """
    Fetch S&P 500 data
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching S&P 500 from Yahoo Finance...")
    symbol = M9_STOCK_INDICES['USA']
    observations = fetch_yahoo_stock(symbol, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetcher
    data = fetch_usa_stock(days_back=7)
    
    if data:
        latest = data[-1]
        print(f"\nS&P 500: {latest[1]:.2f} (as of {latest[0]})")