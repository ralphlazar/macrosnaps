"""
Multi-Level Claude API Service for MacroSnaps
Generates content for 3 expertise levels: BEGINNER, MODERATE, EXPERT
"""
import os
import json
import time
from datetime import date
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import anthropic
from anthropic import APIError, APIConnectionError, RateLimitError


@dataclass
class MultiLevelStory:
    """Container for stories at all 3 expertise levels"""
    beginner: List[str]  # 3 bullets for beginners
    moderate: List[str]  # 3 bullets for moderate users
    expert: List[str]    # 3 bullets for experts


@dataclass
class MultiLevelHeadline:
    """Container for headlines at all 3 expertise levels"""
    beginner: str
    moderate: str
    expert: str


# ── Country editorial context ──
# Gives the AI thematic anchors so it doesn't just recite numbers
COUNTRY_CONTEXT = {
    'USA': {
        'themes': 'Fed policy path, soft landing vs recession debate, AI-driven productivity, fiscal sustainability, Mag 7 concentration risk, tariff/trade policy shifts',
        'personality': 'the anchor of global macro — everything here ripples outward'
    },
    'CAN': {
        'themes': 'BoC easing cycle, mortgage renewal wall, immigration surge vs per-capita stagnation, oil/WTI dependency, housing affordability crisis, USMCA trade exposure',
        'personality': 'caught between its own housing bubble and its neighbor\'s gravity'
    },
    'GBR': {
        'themes': 'post-Brexit structural adjustment, services inflation stickiness, gilt market credibility post-LDI crisis, productivity puzzle, NHS/infrastructure investment gap',
        'personality': 'still finding its post-Brexit identity while battling stubborn inflation'
    },
    'JPN': {
        'themes': 'BoJ normalization after decades of deflation, Shunto wage dynamics, yen weakness (REER at 50-year lows), corporate governance reform (TSE P/B push), sogo shosha re-rating, demographic headwinds',
        'personality': 'a generational turning point — the end of deflation is rewriting every assumption'
    },
    'DEU': {
        'themes': 'manufacturing recession, Schuldenbremse reform debate, Zeitenwende defence spending, energy transition costs, China export dependency, auto sector disruption from EVs',
        'personality': 'Europe\'s engine is sputtering — the old export model is under existential pressure'
    },
    'FRA': {
        'themes': 'political fragmentation (hung parliament), OAT-Bund spread as stress gauge, fiscal slippage and EDP risk, luxury/aerospace strengths, pension reform aftermath',
        'personality': 'strong companies, weak politics — the spread tells the story'
    },
    'ITA': {
        'themes': 'surprising outperformance, NRRP/EU funds execution, BTP-Bund spread compression, banking sector transformation (NPLs 17% to 3%), tourism strength, Superbonus fiscal drag unwinding',
        'personality': 'the comeback story of Europe — defying its "sick man" reputation'
    },
    'CHN': {
        'themes': 'property sector deflation, balance sheet recession risk, PBOC policy constraints (CNY defense vs easing), manufacturing overcapacity exporting deflation, EV/solar dominance, youth unemployment',
        'personality': 'the world\'s second-largest economy grappling with a deflating property bubble and crisis of confidence'
    },
    'IND': {
        'themes': 'demographic dividend, digital infrastructure leapfrog (UPI), capex cycle inflection, RBI credibility, FII vs DII flow dynamics, manufacturing pivot (China+1), SIP revolution in retail investing',
        'personality': 'the world\'s growth star — structural, not cyclical, with a demographic tailwind no one else has'
    }
}


class MultiLevelClaudeGenerator:
    """
    Generate economic content for 3 expertise levels simultaneously.
    More efficient than 3 separate API calls and ensures consistency.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        max_retries: int = 3,
        retry_delay: float = 2.0,
        timeout: int = 60
    ):
        """Initialize multi-level Claude API client"""
        self.client = anthropic.Anthropic(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"),
            timeout=timeout
        )
        self.model = "claude-sonnet-4-20250514"
        self.max_retries = max_retries
        self.retry_delay = retry_delay
    
    def generate_multi_level_stories(
        self,
        country_name: str,
        country_code: str,
        economic_data: Dict
    ) -> MultiLevelStory:
        """
        Generate story bullets for all 3 expertise levels in one API call
        """
        prompt = self._build_multi_level_story_prompt(country_name, country_code, economic_data)
        
        for attempt in range(self.max_retries):
            try:
                message = self.client.messages.create(
                    model=self.model,
                    max_tokens=2000,
                    temperature=0.8,  # Slightly higher for variety
                    messages=[{"role": "user", "content": prompt}]
                )
                
                response_text = message.content[0].text
                stories = self._parse_multi_level_stories(response_text)
                
                if (len(stories.beginner) >= 3 and 
                    len(stories.moderate) >= 3 and 
                    len(stories.expert) >= 3):
                    return stories
                else:
                    print(f"Warning: Incomplete stories generated (attempt {attempt + 1})")
                    if attempt == self.max_retries - 1:
                        return self._fill_missing_stories(stories, country_name, economic_data)
                    continue
                
            except (RateLimitError, APIConnectionError) as e:
                print(f"API error for {country_name} (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (2 ** attempt))
                else:
                    return self._get_fallback_stories(country_name, economic_data)
            
            except Exception as e:
                print(f"Unexpected error for {country_name}: {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
                else:
                    return self._get_fallback_stories(country_name, economic_data)
        
        return self._get_fallback_stories(country_name, economic_data)
    
    def generate_multi_level_headlines(
        self,
        country_name: str,
        economic_data: Dict
    ) -> MultiLevelHeadline:
        """Generate headlines for all 3 expertise levels"""
        
        prompt = self._build_multi_level_headline_prompt(country_name, economic_data)
        
        for attempt in range(self.max_retries):
            try:
                message = self.client.messages.create(
                    model=self.model,
                    max_tokens=500,
                    temperature=0.9,
                    messages=[{"role": "user", "content": prompt}]
                )
                
                response_text = message.content[0].text
                headlines = self._parse_multi_level_headlines(response_text)
                
                if headlines:
                    return headlines
                
            except Exception as e:
                print(f"Error generating headlines: {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
        
        return self._get_fallback_headlines(country_name, economic_data)
    
    def _build_multi_level_story_prompt(
        self,
        country_name: str,
        country_code: str,
        economic_data: Dict
    ) -> str:
        """Build prompt to generate rich, editorial stories for all 3 levels"""
        
        macro = economic_data.get('macroeconomic', [])
        markets = economic_data.get('markets', [])
        
        # Format data
        macro_text = []
        for metric in macro:
            name = metric.get('name', '')
            value = metric.get('display_value', 'N/A')
            label = metric.get('display_label', '')
            trend = metric.get('trend', {})
            trend_desc = f" ({trend.get('arrow', '')} {trend.get('description', '')})" if trend else ""
            macro_text.append(f"  {name}: {value} ({label}){trend_desc}")
        
        market_text = []
        for metric in markets:
            name = metric.get('name', '')
            value = metric.get('value', 'N/A')
            dt = metric.get('date', '')
            trend = metric.get('trend', {})
            trend_desc = f" ({trend.get('arrow', '')} {trend.get('description', '')})" if trend else ""
            market_text.append(f"  {name}: {value} ({dt}){trend_desc}")
        
        # Get country context
        ctx = COUNTRY_CONTEXT.get(country_code, {
            'themes': 'economic conditions, policy outlook, market dynamics',
            'personality': 'evolving economic landscape'
        })
        
        today = date.today().strftime('%B %d, %Y')
        
        prompt = f"""You are a sharp, opinionated macro strategist writing daily briefing cards for {country_name}. Today is {today}.

You are NOT a data reader. You are an analyst who tells a STORY. The data is evidence for your narrative, not the narrative itself.

COUNTRY CHARACTER: {ctx['personality']}
KEY THEMES TO DRAW FROM: {ctx['themes']}

TODAY'S DATA:
Macro:
{chr(10).join(macro_text) if macro_text else "  Limited data available"}
Markets:
{chr(10).join(market_text) if market_text else "  Limited data available"}

CRITICAL RULES:
1. DO NOT just read out numbers. Weave them into insight.
2. Each bullet should make a POINT, not state a fact.
3. Vary your structure — don't start every bullet the same way.
4. Connect dots: link data to policy, policy to markets, markets to real life.
5. Have a perspective. Be interesting. Surprise the reader.
6. Use the numbers as evidence, not as the story.

Generate exactly 3 bullets for each level:

══════════════════════════════════
BEGINNER (Curious people, students)
══════════════════════════════════
Voice: Like a smart friend explaining over coffee. Warm, clear, no jargon.
DO: Use analogies, explain cause-and-effect, make it feel relevant to daily life.
DON'T: Be condescending, use acronyms, or just simplify the moderate version.
Length: 15-25 words per bullet.

GOOD examples:
- "After 30 years of stagnation, Japan is finally seeing something it hasn't had in a generation — inflation and wage growth"
- "The government faces a tough choice: spend more to grow the economy, or tighten the belt to control rising debt"
- "Factory closures are piling up as cheap energy disappears — Germany's industrial engine needs a new fuel source"

BAD examples:
- "GDP grew 3.2%" (just reading data)
- "The economy is growing at a moderate pace" (boring, vague)
- "Inflation is at 2.8%, which measures price increases" (textbook, not editorial)

══════════════════════════════════
MODERATE (Undergrads, informed investors)
══════════════════════════════════
Voice: Bloomberg-lite. Concise, confident, analytical.
DO: Use standard finance terms, reference policy frameworks, identify tensions and tradeoffs.
DON'T: Over-explain basics or be as dense as the expert level.
Length: 12-20 words per bullet.

GOOD examples:
- "BoC leading the G7 easing cycle — rate cuts underway as housing correction weighs on consumer spending"
- "BTP-Bund compression to 120bp reflects genuine fiscal improvement, not just ECB backstop credibility"
- "The mortgage renewal wall means rate cuts may not rescue households fast enough — timing mismatch risk"

BAD examples:
- "GDP growth at 3.2%, indicating solid economic expansion" (data readout, no insight)
- "Inflation cooling toward target" (too brief, no edge)
- "Markets performed well this quarter" (says nothing)

══════════════════════════════════
EXPERT (Professionals, economists, PMs)
══════════════════════════════════
Voice: Macro research note. Dense, precise, opinionated.
DO: Use technical terms freely (PCE, OIS, REER, r-g dynamics). Reference models and frameworks. Include specific numbers. Identify the key trading or policy question.
DON'T: Explain what terms mean. Assume the reader knows everything.
Length: 15-25 words per bullet.

GOOD examples:
- "OAT-Bund at ~80bp decomposition: ~40bp political risk, ~30bp fiscal fundamentals, ~10bp liquidity"
- "Shunto 5%+ validates BoJ's virtuous cycle thesis — but sustainability depends on SME pass-through and service-sector pricing power"
- "PBOC trapped: easing pressures CNY (CNH-CNY basis widening signals outflow), but inaction risks debt-deflation spiral deepening"

BAD examples:
- "GDP expanding 3.2%; assess composition" (generic)
- "Monitor inflation trends" (vapid)
- "Equities elevated, monitor volatility" (could be any country any day)

FORMAT YOUR RESPONSE EXACTLY LIKE THIS:

BEGINNER:
- [bullet]
- [bullet]
- [bullet]

MODERATE:
- [bullet]
- [bullet]
- [bullet]

EXPERT:
- [bullet]
- [bullet]
- [bullet]"""

        return prompt
    
    def _build_multi_level_headline_prompt(
        self,
        country_name: str,
        economic_data: Dict
    ) -> str:
        """Build prompt to generate headlines for all 3 levels"""
        
        macro = economic_data.get('macroeconomic', [])
        markets = economic_data.get('markets', [])
        
        data_summary = []
        for m in macro:
            data_summary.append(f"{m.get('name', '')}: {m.get('display_value', 'N/A')}")
        for m in markets[:2]:
            data_summary.append(f"{m.get('name', '')}: {m.get('value', 'N/A')}")
        
        prompt = f"""Write 3 headline versions for {country_name}'s economic card today.

Data snapshot:
{chr(10).join(data_summary) if data_summary else "Limited data"}

Rules:
- Headlines should have ATTITUDE, not just state facts
- Never start with the country name
- Never use "Update" or "Snapshot" or "Overview" — those are filler words
- Each headline should make the reader want to read more

BEGINNER (6-10 words, no jargon, vivid):
Good: "Paychecks Are Finally Growing — But So Are Prices"
Good: "The Factory Slowdown That's Worrying Europe"
Bad: "Economy Growing Steadily" (boring)
Bad: "United States Economy Update" (generic)

MODERATE (5-8 words, punchy, financial):
Good: "Soft Landing Holds — For Now"
Good: "Rate Cuts Begin, Housing Still Hurting"
Bad: "Growth Accelerates Amid Cooling Inflation" (formulaic)

EXPERT (4-8 words, dense, policy-focused):
Good: "r-g Turning Positive, Fiscal Space Shrinking"
Good: "YCC Exit Reprices Duration — Yen Still Trapped"
Bad: "Macro Conditions Evolving" (empty)

FORMAT:
BEGINNER: [headline]
MODERATE: [headline]
EXPERT: [headline]"""

        return prompt
    
    def _parse_multi_level_stories(self, response_text: str) -> MultiLevelStory:
        """Parse the response into MultiLevelStory structure"""
        
        beginner_bullets = []
        moderate_bullets = []
        expert_bullets = []
        
        current_level = None
        
        for line in response_text.strip().split('\n'):
            line = line.strip()
            
            if 'BEGINNER:' in line.upper() or line.upper().startswith('BEGINNER'):
                current_level = 'beginner'
                continue
            elif 'MODERATE:' in line.upper() or line.upper().startswith('MODERATE'):
                current_level = 'moderate'
                continue
            elif 'EXPERT:' in line.upper() or line.upper().startswith('EXPERT'):
                current_level = 'expert'
                continue
            
            if not line:
                continue
            
            # Parse bullet points
            if line.startswith('- ') or line.startswith('* ') or line.startswith('• '):
                bullet = line[2:].strip()
            elif line and line[0].isdigit() and '.' in line[:3]:
                bullet = line.split('.', 1)[1].strip()
            else:
                bullet = line
            
            # Strip any wrapping quotes
            bullet = bullet.strip('"\'')
            
            if current_level == 'beginner' and bullet:
                beginner_bullets.append(bullet)
            elif current_level == 'moderate' and bullet:
                moderate_bullets.append(bullet)
            elif current_level == 'expert' and bullet:
                expert_bullets.append(bullet)
        
        return MultiLevelStory(
            beginner=beginner_bullets[:3],
            moderate=moderate_bullets[:3],
            expert=expert_bullets[:3]
        )
    
    def _parse_multi_level_headlines(self, response_text: str) -> Optional[MultiLevelHeadline]:
        """Parse headlines from response"""
        
        beginner = None
        moderate = None
        expert = None
        
        for line in response_text.strip().split('\n'):
            line = line.strip()
            
            if 'BEGINNER:' in line.upper():
                beginner = line.split(':', 1)[1].strip().strip('"\'')
            elif 'MODERATE:' in line.upper():
                moderate = line.split(':', 1)[1].strip().strip('"\'')
            elif 'EXPERT:' in line.upper():
                expert = line.split(':', 1)[1].strip().strip('"\'')
        
        if beginner and moderate and expert:
            return MultiLevelHeadline(
                beginner=beginner,
                moderate=moderate,
                expert=expert
            )
        
        return None
    
    def _fill_missing_stories(
        self,
        stories: MultiLevelStory,
        country_name: str,
        economic_data: Dict
    ) -> MultiLevelStory:
        """Fill in any missing stories with fallbacks"""
        
        fallback = self._get_fallback_stories(country_name, economic_data)
        
        while len(stories.beginner) < 3:
            stories.beginner.append(fallback.beginner[len(stories.beginner)])
        while len(stories.moderate) < 3:
            stories.moderate.append(fallback.moderate[len(stories.moderate)])
        while len(stories.expert) < 3:
            stories.expert.append(fallback.expert[len(stories.expert)])
        
        return stories
    
    def _get_fallback_stories(
        self,
        country_name: str,
        economic_data: Dict
    ) -> MultiLevelStory:
        """Generate simple fallback stories for all 3 levels"""
        
        macro = economic_data.get('macroeconomic', [])
        markets = economic_data.get('markets', [])
        
        beginner = []
        moderate = []
        expert = []
        
        gdp = next((m for m in macro if 'GDP' in m.get('name', '')), None)
        if gdp and gdp.get('display_value') != 'N/A':
            value = gdp.get('display_value')
            beginner.append(f"The economy grew {value}, meaning more jobs and business activity")
            moderate.append(f"GDP growth at {value}, indicating solid economic expansion")
            expert.append(f"GDP expanding {value}; assess composition and sustainability")
        
        inflation = next((m for m in macro if 'Inflation' in m.get('name', '')), None)
        if inflation and inflation.get('display_value') != 'N/A':
            value = inflation.get('display_value')
            beginner.append(f"Prices rising {value} per year, affecting what things cost")
            moderate.append(f"Inflation at {value}, moderating from recent peaks")
            expert.append(f"CPI inflation {value}; monitor core trends and expectations")
        
        stock = next((m for m in markets if 'YTD' in m.get('name', '') or 'Stock' in m.get('name', '')), None)
        if stock and stock.get('value') != 'N/A':
            value = stock.get('value')
            beginner.append(f"Stock market {value} this year, good for retirement accounts")
            moderate.append(f"Equity markets {value} YTD on investor optimism")
            expert.append(f"Equities {value} YTD; valuations elevated, monitor volatility")
        
        while len(beginner) < 3:
            beginner.append(f"Economic data shows {country_name} continues to develop")
        while len(moderate) < 3:
            moderate.append(f"Additional economic indicators monitored for {country_name}")
        while len(expert) < 3:
            expert.append(f"Monitor additional macro variables and policy signals")
        
        return MultiLevelStory(
            beginner=beginner[:3],
            moderate=moderate[:3],
            expert=expert[:3]
        )
    
    def _get_fallback_headlines(
        self,
        country_name: str,
        economic_data: Dict
    ) -> MultiLevelHeadline:
        """Generate fallback headlines for all 3 levels"""
        return MultiLevelHeadline(
            beginner=f"{country_name} Economy Update Today",
            moderate=f"{country_name} Economic Snapshot",
            expert=f"{country_name} Macro Overview"
        )
    
    def generate_weather_icon(self, economic_data: Dict) -> str:
        """Generate weather icon (same for all levels)"""
        positive_trends = 0
        negative_trends = 0
        
        for metric in economic_data.get('macroeconomic', []):
            trend = metric.get('trend', {})
            color = trend.get('color', 'neutral')
            if color == 'good':
                positive_trends += 1
            elif color == 'bad':
                negative_trends += 1
        
        for metric in economic_data.get('markets', []):
            trend = metric.get('trend', {})
            color = trend.get('color', 'neutral')
            if color == 'good':
                positive_trends += 1
            elif color == 'bad':
                negative_trends += 1
        
        if positive_trends > negative_trends + 1:
            return "☀️"
        elif positive_trends > negative_trends:
            return "🌤️"
        elif negative_trends > positive_trends + 1:
            return "⛈️"
        elif negative_trends > positive_trends:
            return "🌧️"
        else:
            return "☁️"


if __name__ == "__main__":
    generator = MultiLevelClaudeGenerator()
    
    sample_data = {
        'macroeconomic': [
            {
                'name': 'GDP Growth',
                'display_value': '3.2%',
                'display_label': 'Q4 2025',
                'trend': {'arrow': '↗', 'description': 'rising', 'color': 'good'}
            },
            {
                'name': 'Inflation (CPI)',
                'display_value': '2.8%',
                'display_label': 'Jan 2026',
                'trend': {'arrow': '↘', 'description': 'falling', 'color': 'good'}
            }
        ],
        'markets': [
            {
                'name': 'S&P 500 YTD',
                'value': '+8.5%',
                'date': 'Feb 05',
                'trend': {'arrow': '↗', 'description': 'rising', 'color': 'good'}
            }
        ]
    }
    
    print("Generating multi-level stories...")
    stories = generator.generate_multi_level_stories("United States", "USA", sample_data)
    
    print("\n" + "="*60)
    print("BEGINNER LEVEL")
    print("="*60)
    for bullet in stories.beginner:
        print(f"• {bullet}")
    
    print("\n" + "="*60)
    print("MODERATE LEVEL")
    print("="*60)
    for bullet in stories.moderate:
        print(f"• {bullet}")
    
    print("\n" + "="*60)
    print("EXPERT LEVEL")
    print("="*60)
    for bullet in stories.expert:
        print(f"• {bullet}")
    
    print("\n" + "="*60)
    print("HEADLINES")
    print("="*60)
    headlines = generator.generate_multi_level_headlines("United States", sample_data)
    print(f"Beginner: {headlines.beginner}")
    print(f"Moderate: {headlines.moderate}")
    print(f"Expert: {headlines.expert}")