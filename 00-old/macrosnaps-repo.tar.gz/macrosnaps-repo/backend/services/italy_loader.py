"""
Load Italy economic data into the database
"""
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData
from backend.services.italy_fetcher import fetch_italy_data, fetch_italy_stock
from datetime import datetime


def load_italy_data(days_back=1095):
    """
    Fetch Italy data from FRED and save to database
    """
    print("Loading Italy data into database...")
    
    # Fetch data from FRED
    fred_data = fetch_italy_data(days_back=days_back)
    
    with get_db() as db:
        # Get Italy country
        italy = db.query(Country).filter_by(code='ITA').first()
        if not italy:
            print("Error: Italy not found in database")
            return
        
        # Get all metrics
        metrics = {m.code: m for m in db.query(Metric).all()}
        
        total_saved = 0
        
        for metric_code, observations in fred_data.items():
            if not observations:
                print(f"  ⚠ {metric_code}: No data available")
                continue
            
            metric = metrics.get(metric_code)
            if not metric:
                print(f"  ⚠ {metric_code}: Metric not found in database")
                continue
            
            for date, value in observations:
                # Check if data point already exists
                existing = db.query(DailyData).filter_by(
                    country_id=italy.id,
                    metric_id=metric.id,
                    date=date
                ).first()
                
                if existing:
                    # Update existing value
                    existing.value = value
                    existing.source = 'FRED'
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new data point
                    data_point = DailyData(
                        country_id=italy.id,
                        metric_id=metric.id,
                        date=date,
                        value=value,
                        source='FRED'
                    )
                    db.add(data_point)
                
                total_saved += 1
            
            latest = observations[-1]
            print(f"  ✓ {metric_code}: {len(observations)} observations, latest {latest[1]} on {latest[0]}")
        
        db.commit()
        print(f"\n✓ Saved {total_saved} data points to database")


def load_italy_stock_data(days_back=30):
    """
    Fetch Italy stock data from Yahoo Finance and save to database
    """
    print("\nLoading Italy stock data into database...")
    
    # Fetch FTSE MIB data
    stock_data = fetch_italy_stock(days_back=days_back)
    
    if not stock_data:
        print("  ⚠ No stock data available")
        return
    
    with get_db() as db:
        # Get Italy country
        italy = db.query(Country).filter_by(code='ITA').first()
        
        # Get stock_index metric
        metric = db.query(Metric).filter_by(code='stock_index').first()
        
        saved = 0
        for date, value in stock_data:
            # Check if data point already exists
            existing = db.query(DailyData).filter_by(
                country_id=italy.id,
                metric_id=metric.id,
                date=date
            ).first()
            
            if existing:
                existing.value = value
                existing.source = 'Yahoo Finance'
                existing.updated_at = datetime.utcnow()
            else:
                data_point = DailyData(
                    country_id=italy.id,
                    metric_id=metric.id,
                    date=date,
                    value=value,
                    source='Yahoo Finance'
                )
                db.add(data_point)
            
            saved += 1
        
        db.commit()
        latest = stock_data[-1]
        print(f"  ✓ Saved {saved} FTSE MIB observations, latest {latest[1]:.2f} on {latest[0]}")


if __name__ == '__main__':
    # Load FRED data
    load_italy_data(days_back=1095)
    
    # Load stock data
    load_italy_stock_data(days_back=30)
    
    print("\n✓ Italy data loading complete!")