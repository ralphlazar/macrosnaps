"""
Generate economic weather cards using Claude API
"""
from anthropic import Anthropic
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData, Card
from backend.utils.calculations import calculate_yoy_inflation
from datetime import datetime, date
import os
from dotenv import load_dotenv

load_dotenv()

client = Anthropic(api_key=os.getenv('ANTHROPIC_API_KEY'))


def get_country_latest_data(country_code):
    """
    Get latest data for all metrics for a country
    (excludes budget_deficit as it's annual and appears stale)
    
    Returns:
        dict with metric_code: (value, unit, date)
    """
    with get_db() as db:
        country = db.query(Country).filter_by(code=country_code).first()
        if not country:
            return None
        
        data = {}
        for metric in db.query(Metric).all():
            
            # Special handling for inflation
            if metric.code == 'inflation':
                # For Canada, use raw value (already YoY % from FRED)
                if country_code == 'CAN':
                    latest = db.query(DailyData).filter_by(
                        country_id=country.id,
                        metric_id=metric.id
                    ).order_by(DailyData.date.desc()).first()
                    
                    if latest:
                        data['inflation'] = {
                            'value': round(latest.value, 1),
                            'unit': '%',
                            'date': latest.date,
                            'name': 'Inflation Rate (YoY)'
                        }
                else:
                    # For other countries, calculate YoY rate from CPI index
                    rate, as_of = calculate_yoy_inflation(country_code)
                    if rate is not None:
                        data['inflation'] = {
                            'value': rate,
                            'unit': '%',
                            'date': as_of,
                            'name': 'Inflation Rate (YoY)'
                        }
                continue
            
            latest = db.query(DailyData).filter_by(
                country_id=country.id,
                metric_id=metric.id
            ).order_by(DailyData.date.desc()).first()
            
            if latest:
                data[metric.code] = {
                    'value': latest.value,
                    'unit': metric.unit,
                    'date': latest.date,
                    'name': metric.name
                }
        
        return data


def generate_card_prompt(country_code, country_name, data):
    """
    Create prompt for Claude to generate economic card
    """
    data_summary = []
    for metric_code, info in data.items():
        data_summary.append(f"- {info['name']}: {info['value']} {info['unit']} (as of {info['date']})")
    
    data_text = "\n".join(data_summary)
    
    prompt = f"""You are an economic analyst creating a daily "economic weather report" card for {country_name}.

Here is the latest economic data:

{data_text}

Create a card with:

1. HEADLINE: A punchy, engaging headline (max 100 chars) that captures the economic situation
2. STORY: A clear, 2-3 sentence explanation (max 300 chars) of what's happening in the economy. Use simple language, avoid jargon.
3. WEATHER: Choose ONE weather icon that best represents the overall economic climate:
   - ☀️ (sunny) = Strong economy: GDP growing >2%, inflation controlled 2-3%, low unemployment, rising markets
   - ☁️ (cloudy) = Mixed/uncertain: Modest growth 0-2%, inflation concerns, some weakness
   - ⛈️ (stormy) = Weak/troubled: Negative/stagnant growth, high inflation or deflation, rising unemployment, falling markets

Respond ONLY in this exact format:
HEADLINE: [your headline]
STORY: [your story]
WEATHER: [single emoji - only ☀️, ☁️, or ⛈️]"""

    return prompt


def generate_usa_card():
    """
    Generate economic card for USA
    """
    print("Generating USA economic card...")
    
    # Get latest data
    data = get_country_latest_data('USA')
    if not data:
        print("Error: No data available for USA")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('USA', 'United States', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='USA').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_canada_card():
    """
    Generate economic card for Canada
    """
    print("Generating Canada economic card...")
    
    # Get latest data
    data = get_country_latest_data('CAN')
    if not data:
        print("Error: No data available for Canada")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('CAN', 'Canada', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='CAN').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_uk_card():
    """
    Generate economic card for UK
    """
    print("Generating UK economic card...")
    
    # Get latest data
    data = get_country_latest_data('GBR')
    if not data:
        print("Error: No data available for UK")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('GBR', 'United Kingdom', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='GBR').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_japan_card():
    """
    Generate economic card for Japan
    """
    print("Generating Japan economic card...")
    
    # Get latest data
    data = get_country_latest_data('JPN')
    if not data:
        print("Error: No data available for Japan")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('JPN', 'Japan', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='JPN').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_germany_card():
    """
    Generate economic card for Germany
    """
    print("Generating Germany economic card...")
    
    # Get latest data
    data = get_country_latest_data('DEU')
    if not data:
        print("Error: No data available for Germany")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('DEU', 'Germany', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='DEU').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_france_card():
    """
    Generate economic card for France
    """
    print("Generating France economic card...")
    
    # Get latest data
    data = get_country_latest_data('FRA')
    if not data:
        print("Error: No data available for France")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('FRA', 'France', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='FRA').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_italy_card():
    """
    Generate economic card for Italy
    """
    print("Generating Italy economic card...")
    
    # Get latest data
    data = get_country_latest_data('ITA')
    if not data:
        print("Error: No data available for Italy")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('ITA', 'Italy', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='ITA').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_china_card():
    """
    Generate economic card for China
    Note: Only 4/7 metrics available (GDP, unemployment, bond yield missing)
    """
    print("Generating China economic card...")
    
    # Get latest data
    data = get_country_latest_data('CHN')
    if not data:
        print("Error: No data available for China")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('CHN', 'China', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='CHN').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


def generate_india_card():
    """
    Generate economic card for India
    Note: Only 5/7 metrics available (unemployment, bond yield missing)
    """
    print("Generating India economic card...")
    
    # Get latest data
    data = get_country_latest_data('IND')
    if not data:
        print("Error: No data available for India")
        return None
    
    # Create prompt
    prompt = generate_card_prompt('IND', 'India', data)
    
    # Call Claude API
    print("Calling Claude API...")
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    response_text = message.content[0].text
    print(f"Claude response:\n{response_text}\n")
    
    # Parse response
    lines = response_text.strip().split('\n')
    headline = ""
    story = ""
    weather = ""
    
    for line in lines:
        if line.startswith('HEADLINE:'):
            headline = line.replace('HEADLINE:', '').strip()
        elif line.startswith('STORY:'):
            story = line.replace('STORY:', '').strip()
        elif line.startswith('WEATHER:'):
            weather = line.replace('WEATHER:', '').strip()
    
    if not headline or not story or not weather:
        print("Error: Could not parse Claude response")
        return None
    
    # Save to database
    with get_db() as db:
        country = db.query(Country).filter_by(code='IND').first()
        today = date.today()
        
        # Check if card already exists for today
        existing = db.query(Card).filter_by(
            country_id=country.id,
            date=today
        ).first()
        
        if existing:
            existing.headline = headline
            existing.story = story
            existing.weather_icon = weather
            existing.ai_generated = datetime.utcnow()
            existing.updated_at = datetime.utcnow()
            print("✓ Updated existing card")
        else:
            card = Card(
                country_id=country.id,
                date=today,
                headline=headline,
                story=story,
                weather_icon=weather,
                ai_generated=datetime.utcnow()
            )
            db.add(card)
            print("✓ Created new card")
        
        db.commit()
    
    return {
        'headline': headline,
        'story': story,
        'weather': weather
    }


if __name__ == '__main__':
    # Generate USA card
    usa_card = generate_usa_card()
    if usa_card:
        print("\n" + "="*60)
        print(f"🇺🇸 USA ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{usa_card['weather']}  {usa_card['headline']}")
        print(f"\n{usa_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate Canada card
    canada_card = generate_canada_card()
    if canada_card:
        print("\n" + "="*60)
        print(f"🇨🇦 CANADA ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{canada_card['weather']}  {canada_card['headline']}")
        print(f"\n{canada_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate UK card
    uk_card = generate_uk_card()
    if uk_card:
        print("\n" + "="*60)
        print(f"🇬🇧 UK ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{uk_card['weather']}  {uk_card['headline']}")
        print(f"\n{uk_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate Japan card
    japan_card = generate_japan_card()
    if japan_card:
        print("\n" + "="*60)
        print(f"🇯🇵 JAPAN ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{japan_card['weather']}  {japan_card['headline']}")
        print(f"\n{japan_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate Germany card
    germany_card = generate_germany_card()
    if germany_card:
        print("\n" + "="*60)
        print(f"🇩🇪 GERMANY ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{germany_card['weather']}  {germany_card['headline']}")
        print(f"\n{germany_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate France card
    france_card = generate_france_card()
    if france_card:
        print("\n" + "="*60)
        print(f"🇫🇷 FRANCE ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{france_card['weather']}  {france_card['headline']}")
        print(f"\n{france_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate Italy card
    italy_card = generate_italy_card()
    if italy_card:
        print("\n" + "="*60)
        print(f"🇮🇹 ITALY ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{italy_card['weather']}  {italy_card['headline']}")
        print(f"\n{italy_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate China card
    china_card = generate_china_card()
    if china_card:
        print("\n" + "="*60)
        print(f"🇨🇳 CHINA ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{china_card['weather']}  {china_card['headline']}")
        print(f"\n{china_card['story']}")
        print("\n" + "="*60)
    
    print("\n")
    
    # Generate India card
    india_card = generate_india_card()
    if india_card:
        print("\n" + "="*60)
        print(f"🇮🇳 INDIA ECONOMIC WEATHER - {date.today()}")
        print("="*60)
        print(f"\n{india_card['weather']}  {india_card['headline']}")
        print(f"\n{india_card['story']}")
        print("\n" + "="*60)