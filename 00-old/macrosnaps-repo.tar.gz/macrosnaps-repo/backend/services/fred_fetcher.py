"""
FRED API data fetcher for USA economic data
"""
import requests
import os
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()

FRED_API_KEY = os.getenv('FRED_API_KEY')
FRED_BASE_URL = 'https://api.stlouisfed.org/fred/series/observations'


# FRED series IDs for USA metrics
USA_SERIES = {
    'gdp_growth': 'A191RL1Q225SBEA',      # Real GDP growth rate (quarterly)
    'inflation': 'CPIAUCSL',              # CPI all items
    'unemployment': 'UNRATE',             # Unemployment rate
    'budget_deficit': 'FYFSGDA188S',      # Federal surplus/deficit as % GDP
    'policy_rate': 'FEDFUNDS',            # Federal funds rate
    'stock_index': None,                   # Will use Yahoo Finance for S&P 500
    'bond_yield': 'DGS10',                # 10-year Treasury yield
    'currency': None,                      # USD is base currency
}


def fetch_fred_series(series_id, days_back=30):
    """
    Fetch data from FRED API for a specific series
    
    Args:
        series_id: FRED series identifier
        days_back: Number of days of history to fetch
    
    Returns:
        List of (date, value) tuples
    """
    if not series_id:
        return []
    
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days_back)
    
    params = {
        'series_id': series_id,
        'api_key': FRED_API_KEY,
        'file_type': 'json',
        'observation_start': start_date.strftime('%Y-%m-%d'),
        'observation_end': end_date.strftime('%Y-%m-%d'),
    }
    
    try:
        response = requests.get(FRED_BASE_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        observations = []
        for obs in data.get('observations', []):
            date_str = obs['date']
            value_str = obs['value']
            
            # Skip missing values
            if value_str == '.':
                continue
            
            date = datetime.strptime(date_str, '%Y-%m-%d').date()
            value = float(value_str)
            observations.append((date, value))
        
        return observations
    
    except requests.exceptions.RequestException as e:
        print(f"Error fetching {series_id}: {e}")
        return []


def fetch_usa_data(days_back=30):
    """
    Fetch all USA economic data from FRED
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching USA data from FRED...")
    results = {}
    
    for metric_code, series_id in USA_SERIES.items():
        if not series_id:
            continue
        
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    return results


if __name__ == '__main__':
    # Test the fetcher
    data = fetch_usa_data(days_back=7)
    
    print("\n=== FRED Data Summary ===")
    for metric, observations in data.items():
        if observations:
            latest = observations[-1]
            print(f"{metric}: {latest[1]} (as of {latest[0]})")