"""
Load custom 2026 forecasts from Google Sheets
"""
import pandas as pd
import requests
from io import StringIO

# Google Sheet ID (extracted from URL)
SHEET_ID = '1t0DKsZcCDj3GojF1TzszZQGLR4oqgppuBbmsldsHj8E'

def get_custom_forecasts():
    """
    Load 2026 forecasts from public Google Sheet
    Returns dict: {country_code: {metric_code: forecast_value}}
    """
    try:
        # Read public Google Sheet as CSV using requests
        url = f'https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv'
        
        response = requests.get(url)
        response.raise_for_status()
        
        # Parse CSV from response text
        df = pd.read_csv(StringIO(response.text))
        
        # Convert to dict format
        forecasts = {}
        for _, row in df.iterrows():
            country_code = row['Country']
            forecasts[country_code] = {
                'gdp_growth': float(row['GDP_Growth_2026']),
                'inflation': float(row['Inflation_2026']),
                'budget_deficit': float(row['Budget_Deficit_2026']),
                'current_account': float(row['Current_Account_2026'])
            }
        
        print(f"✓ Loaded custom forecasts for {len(forecasts)} countries from Google Sheet")
        return forecasts
        
    except Exception as e:
        print(f"⚠ Error loading Google Sheet: {e}")
        return None


if __name__ == '__main__':
    forecasts = get_custom_forecasts()
    if forecasts:
        print("\nCustom Forecasts Loaded:")
        for country, data in forecasts.items():
            print(f"  {country}: GDP={data['gdp_growth']}%, Inflation={data['inflation']}%")
    else:
        print("\n✗ Failed to load forecasts")
