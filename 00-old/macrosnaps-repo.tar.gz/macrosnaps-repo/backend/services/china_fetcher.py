"""
Fetch China economic data from FRED, Yahoo Finance, and IMF WEO
Note: China data availability in FRED is limited (only 4/7 metrics available)
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for China
# Note: GDP growth, unemployment, and bond yield not reliably available in FRED
CHINA_SERIES = {
    # 'gdp_growth': Not available with recent data
    'inflation': 'CHNCPIALLMINMEI',
    # 'unemployment': Not available
    'policy_rate': 'IRSTCI01CNM156N',
    # 'bond_yield': Not available
    'currency': 'DEXCHUS',
    'current_account': 'CHNB6BLTT02STSAQ',
}

CHINA_STOCK_SYMBOL = '000001.SS'


def fetch_china_data(days_back=730):
    """
    Fetch all China economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching China data from FRED and IMF WEO...")
    print("  Note: Only 5/9 metrics available (GDP, unemployment, bond yield missing)")
    results = {}
    
    for metric_code, series_id in CHINA_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('CHN')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_china_stock(days_back=30):
    """
    Fetch Shanghai Composite data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching Shanghai Composite from Yahoo Finance...")
    observations = fetch_yahoo_stock(CHINA_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing China Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_china_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_china_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"Shanghai Composite: {latest[1]:.2f} (as of {latest[0]})")