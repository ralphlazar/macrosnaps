"""
Load economic data into the database
"""
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData
from backend.services.fred_fetcher import fetch_usa_data
from backend.services.yahoo_fetcher import fetch_usa_stock
from datetime import datetime


def load_usa_data(days_back=90):
    """
    Fetch USA data from FRED and save to database
    """
    print("Loading USA data into database...")
    
    # Fetch data from FRED
    fred_data = fetch_usa_data(days_back=days_back)
    
    with get_db() as db:
        # Get USA country
        usa = db.query(Country).filter_by(code='USA').first()
        if not usa:
            print("Error: USA not found in database")
            return
        
        # Get all metrics
        metrics = {m.code: m for m in db.query(Metric).all()}
        
        total_saved = 0
        
        for metric_code, observations in fred_data.items():
            if not observations:
                print(f"  ⚠ {metric_code}: No data available")
                continue
            
            metric = metrics.get(metric_code)
            if not metric:
                print(f"  ⚠ {metric_code}: Metric not found in database")
                continue
            
            for date, value in observations:
                # Check if data point already exists
                existing = db.query(DailyData).filter_by(
                    country_id=usa.id,
                    metric_id=metric.id,
                    date=date
                ).first()
                
                if existing:
                    # Update existing value
                    existing.value = value
                    existing.source = 'FRED'
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new data point
                    data_point = DailyData(
                        country_id=usa.id,
                        metric_id=metric.id,
                        date=date,
                        value=value,
                        source='FRED'
                    )
                    db.add(data_point)
                
                total_saved += 1
            
            latest = observations[-1]
            print(f"  ✓ {metric_code}: {len(observations)} observations, latest {latest[1]} on {latest[0]}")
        
        db.commit()
        print(f"\n✓ Saved {total_saved} data points to database")


def load_usa_stock_data(days_back=30):
    """
    Fetch USA stock data from Yahoo Finance and save to database
    """
    print("\nLoading USA stock data into database...")
    
    # Fetch S&P 500 data
    stock_data = fetch_usa_stock(days_back=days_back)
    
    if not stock_data:
        print("  ⚠ No stock data available")
        return
    
    with get_db() as db:
        # Get USA country
        usa = db.query(Country).filter_by(code='USA').first()
        
        # Get stock_index metric
        metric = db.query(Metric).filter_by(code='stock_index').first()
        
        saved = 0
        for date, value in stock_data:
            # Check if data point already exists
            existing = db.query(DailyData).filter_by(
                country_id=usa.id,
                metric_id=metric.id,
                date=date
            ).first()
            
            if existing:
                existing.value = value
                existing.source = 'Yahoo Finance'
                existing.updated_at = datetime.utcnow()
            else:
                data_point = DailyData(
                    country_id=usa.id,
                    metric_id=metric.id,
                    date=date,
                    value=value,
                    source='Yahoo Finance'
                )
                db.add(data_point)
            
            saved += 1
        
        db.commit()
        latest = stock_data[-1]
        print(f"  ✓ Saved {saved} S&P 500 observations, latest {latest[1]:.2f} on {latest[0]}")


def get_latest_usa_data():
    """
    Retrieve latest USA data from database
    """
    with get_db() as db:
        usa = db.query(Country).filter_by(code='USA').first()
        
        print(f"\n=== Latest USA Data (from database) ===")
        
        for metric in db.query(Metric).order_by(Metric.display_order).all():
            latest = db.query(DailyData).filter_by(
                country_id=usa.id,
                metric_id=metric.id
            ).order_by(DailyData.date.desc()).first()
            
            if latest:
                print(f"{metric.name}: {latest.value} {metric.unit} (as of {latest.date})")
            else:
                print(f"{metric.name}: No data")


if __name__ == '__main__':
    # Load FRED data (fetch 2 years for quarterly/annual data)
    load_usa_data(days_back=730)
    
    # Load stock data
    load_usa_stock_data(days_back=30)
    
    # Display what we loaded
    get_latest_usa_data()