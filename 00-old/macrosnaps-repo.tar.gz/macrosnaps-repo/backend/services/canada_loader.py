"""
Load Canada economic data into the database
"""
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData
from backend.services.canada_fetcher import fetch_canada_data, fetch_canada_stock
from datetime import datetime


def load_canada_data(days_back=1095):
    """
    Fetch Canada data from FRED/WEO and save to database
    """
    print("Loading Canada data into database...")
    
    # Fetch data
    canada_data = fetch_canada_data(days_back=days_back)
    
    with get_db() as db:
        # Get Canada country
        canada = db.query(Country).filter_by(code='CAN').first()
        if not canada:
            print("Error: Canada not found in database")
            return
        
        # Get all metrics
        metrics = {m.code: m for m in db.query(Metric).all()}
        
        total_saved = 0
        
        for metric_code, observations in canada_data.items():
            if not observations:
                print(f"  ⚠ {metric_code}: No data available")
                continue
            
            metric = metrics.get(metric_code)
            if not metric:
                print(f"  ⚠ {metric_code}: Metric not found in database")
                continue
            
            for date, value in observations:
                # Check if data point already exists
                existing = db.query(DailyData).filter_by(
                    country_id=canada.id,
                    metric_id=metric.id,
                    date=date
                ).first()
                
                source = 'IMF WEO' if metric_code == 'budget_deficit' else 'FRED'
                
                if existing:
                    existing.value = value
                    existing.source = source
                    existing.updated_at = datetime.utcnow()
                else:
                    data_point = DailyData(
                        country_id=canada.id,
                        metric_id=metric.id,
                        date=date,
                        value=value,
                        source=source
                    )
                    db.add(data_point)
                
                total_saved += 1
            
            latest = observations[-1]
            print(f"  ✓ {metric_code}: {len(observations)} observations, latest {latest[1]} on {latest[0]}")
        
        db.commit()
        print(f"\n✓ Saved {total_saved} data points to database")


def load_canada_stock_data(days_back=30):
    """
    Fetch Canada stock data from Yahoo Finance and save to database
    """
    print("\nLoading Canada stock data into database...")
    
    stock_data = fetch_canada_stock(days_back=days_back)
    
    if not stock_data:
        print("  ⚠ No stock data available")
        return
    
    with get_db() as db:
        canada = db.query(Country).filter_by(code='CAN').first()
        metric = db.query(Metric).filter_by(code='stock_index').first()
        
        saved = 0
        for date, value in stock_data:
            existing = db.query(DailyData).filter_by(
                country_id=canada.id,
                metric_id=metric.id,
                date=date
            ).first()
            
            if existing:
                existing.value = value
                existing.source = 'Yahoo Finance'
                existing.updated_at = datetime.utcnow()
            else:
                data_point = DailyData(
                    country_id=canada.id,
                    metric_id=metric.id,
                    date=date,
                    value=value,
                    source='Yahoo Finance'
                )
                db.add(data_point)
            
            saved += 1
        
        db.commit()
        latest = stock_data[-1]
        print(f"  ✓ Saved {saved} S&P/TSX observations, latest {latest[1]:.2f} on {latest[0]}")


if __name__ == '__main__':
    load_canada_data(days_back=1095)
    load_canada_stock_data(days_back=30)
    print("\n✓ Canada data loading complete!")