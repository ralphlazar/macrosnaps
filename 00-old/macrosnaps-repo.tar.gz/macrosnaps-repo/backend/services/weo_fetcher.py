"""
Fetch fiscal data from IMF World Economic Outlook database
"""
from imf_reader import weo
from datetime import date


def fetch_weo_budget_balance(country_code):
    """
    Fetch budget balance (% of GDP) for a country from IMF WEO
    
    Args:
        country_code: ISO 3-letter code (USA, CAN, GBR, etc.)
    
    Returns:
        List of (date, value) tuples
    """
    # Fetch WEO database (cached after first call)
    df = weo.fetch_data()
    
    # Filter for budget balance indicator
    budget_df = df[df['CONCEPT_CODE'] == 'GGXCNL_NGDP']
    
    # Filter for country
    country_data = budget_df[budget_df['REF_AREA_CODE'] == country_code]
    
    if country_data.empty:
        return []
    
    # Filter for actual years only (<=2024) and recent years
    country_data = country_data[country_data['TIME_PERIOD'].astype(int) <= 2024]
    country_data = country_data[country_data['TIME_PERIOD'].astype(int) >= 2020]
    
    # Convert to list of (date, value) tuples
    # Use Jan 1 of each year as the date
    results = []
    for _, row in country_data.iterrows():
        year = int(row['TIME_PERIOD'])
        value = float(row['OBS_VALUE'])
        obs_date = date(year, 1, 1)
        results.append((obs_date, value))
    
    # Sort by date
    results.sort(key=lambda x: x[0])
    
    return results


if __name__ == '__main__':
    # Test the fetcher
    print("=== Testing WEO Budget Balance Fetcher ===\n")
    
    countries = ['USA', 'CAN', 'GBR', 'JPN', 'DEU', 'FRA', 'ITA', 'CHN', 'IND']
    
    for country in countries:
        data = fetch_weo_budget_balance(country)
        if data:
            latest = data[-1]
            print(f"{country}: {latest[1]}% on {latest[0]} - {len(data)} obs")
        else:
            print(f"{country}: No data")