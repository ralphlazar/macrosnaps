"""
Fetch Germany economic data from FRED, Yahoo Finance, and IMF WEO
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for Germany
GERMANY_SERIES = {
    'gdp_growth': 'NAEXKP01DEQ657S',
    'inflation': 'DEUCPIALLMINMEI',
    'unemployment': 'LRHUTTTTDEM156S',
    'policy_rate': 'IRSTCI01DEM156N',
    'bond_yield': 'IRLTLT01DEM156N',
    'currency': 'DEXUSEU',
    'current_account': 'DEUB6BLTT02STSAQ',
}

GERMANY_STOCK_SYMBOL = '^GDAXI'


def fetch_germany_data(days_back=730):
    """
    Fetch all Germany economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching Germany data from FRED and IMF WEO...")
    results = {}
    
    for metric_code, series_id in GERMANY_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('DEU')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_germany_stock(days_back=30):
    """
    Fetch DAX data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching DAX from Yahoo Finance...")
    observations = fetch_yahoo_stock(GERMANY_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing Germany Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_germany_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_germany_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"DAX: {latest[1]:.2f} (as of {latest[0]})")