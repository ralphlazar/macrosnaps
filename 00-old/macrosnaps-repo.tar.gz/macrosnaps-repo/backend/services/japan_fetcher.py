"""
Fetch Japan economic data from FRED, Yahoo Finance, and IMF WEO
Note: Japan inflation data not available in FRED
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for Japan
# Note: Japan CPI data not available in FRED, skipping inflation
JAPAN_SERIES = {
    'gdp_growth': 'NAEXKP01JPQ657S',
    # 'inflation': No reliable series available in FRED
    'unemployment': 'LRHUTTTTJPM156S',
    'policy_rate': 'IRSTCI01JPM156N',
    'bond_yield': 'IRLTLT01JPM156N',
    'currency': 'DEXJPUS',
    'current_account': 'JPNB6BLTT02STSAQ',
}

JAPAN_STOCK_SYMBOL = '^N225'


def fetch_japan_data(days_back=730):
    """
    Fetch all Japan economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching Japan data from FRED and IMF WEO...")
    results = {}
    
    for metric_code, series_id in JAPAN_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('JPN')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_japan_stock(days_back=30):
    """
    Fetch Nikkei 225 data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching Nikkei 225 from Yahoo Finance...")
    observations = fetch_yahoo_stock(JAPAN_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing Japan Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_japan_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_japan_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"Nikkei 225: {latest[1]:.2f} (as of {latest[0]})")