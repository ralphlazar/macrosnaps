"""
Load China economic data into the database
Note: Only 4/7 metrics available (GDP, unemployment, bond yield missing from FRED)
"""
from backend.utils.database import get_db
from backend.models.schema import Country, Metric, DailyData
from backend.services.china_fetcher import fetch_china_data, fetch_china_stock
from datetime import datetime


def load_china_data(days_back=1095):
    """
    Fetch China data from FRED and save to database
    """
    print("Loading China data into database...")
    
    # Fetch data from FRED
    fred_data = fetch_china_data(days_back=days_back)
    
    with get_db() as db:
        # Get China country
        china = db.query(Country).filter_by(code='CHN').first()
        if not china:
            print("Error: China not found in database")
            return
        
        # Get all metrics
        metrics = {m.code: m for m in db.query(Metric).all()}
        
        total_saved = 0
        
        for metric_code, observations in fred_data.items():
            if not observations:
                print(f"  ⚠ {metric_code}: No data available")
                continue
            
            metric = metrics.get(metric_code)
            if not metric:
                print(f"  ⚠ {metric_code}: Metric not found in database")
                continue
            
            for date, value in observations:
                # Check if data point already exists
                existing = db.query(DailyData).filter_by(
                    country_id=china.id,
                    metric_id=metric.id,
                    date=date
                ).first()
                
                if existing:
                    # Update existing value
                    existing.value = value
                    existing.source = 'FRED'
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new data point
                    data_point = DailyData(
                        country_id=china.id,
                        metric_id=metric.id,
                        date=date,
                        value=value,
                        source='FRED'
                    )
                    db.add(data_point)
                
                total_saved += 1
            
            latest = observations[-1]
            print(f"  ✓ {metric_code}: {len(observations)} observations, latest {latest[1]} on {latest[0]}")
        
        db.commit()
        print(f"\n✓ Saved {total_saved} data points to database")


def load_china_stock_data(days_back=30):
    """
    Fetch China stock data from Yahoo Finance and save to database
    """
    print("\nLoading China stock data into database...")
    
    # Fetch Shanghai Composite data
    stock_data = fetch_china_stock(days_back=days_back)
    
    if not stock_data:
        print("  ⚠ No stock data available")
        return
    
    with get_db() as db:
        # Get China country
        china = db.query(Country).filter_by(code='CHN').first()
        
        # Get stock_index metric
        metric = db.query(Metric).filter_by(code='stock_index').first()
        
        saved = 0
        for date, value in stock_data:
            # Check if data point already exists
            existing = db.query(DailyData).filter_by(
                country_id=china.id,
                metric_id=metric.id,
                date=date
            ).first()
            
            if existing:
                existing.value = value
                existing.source = 'Yahoo Finance'
                existing.updated_at = datetime.utcnow()
            else:
                data_point = DailyData(
                    country_id=china.id,
                    metric_id=metric.id,
                    date=date,
                    value=value,
                    source='Yahoo Finance'
                )
                db.add(data_point)
            
            saved += 1
        
        db.commit()
        latest = stock_data[-1]
        print(f"  ✓ Saved {saved} Shanghai Composite observations, latest {latest[1]:.2f} on {latest[0]}")


if __name__ == '__main__':
    # Load FRED data
    load_china_data(days_back=1095)
    
    # Load stock data
    load_china_stock_data(days_back=30)
    
    print("\n✓ China data loading complete!")
    print("  Note: GDP growth, unemployment, and bond yield unavailable in FRED")