"""
Fetch France economic data from FRED, Yahoo Finance, and IMF WEO
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for France
FRANCE_SERIES = {
    'gdp_growth': 'NAEXKP01FRQ657S',
    'inflation': 'FRACPIALLMINMEI',
    'unemployment': 'LRHUTTTTFRM156S',
    'policy_rate': 'IRSTCI01FRM156N',
    'bond_yield': 'IRLTLT01FRM156N',
    'currency': 'DEXUSEU',
    'current_account': 'FRAB6BLTT02STSAQ',
}

FRANCE_STOCK_SYMBOL = '^FCHI'


def fetch_france_data(days_back=730):
    """
    Fetch all France economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching France data from FRED and IMF WEO...")
    results = {}
    
    for metric_code, series_id in FRANCE_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('FRA')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_france_stock(days_back=30):
    """
    Fetch CAC 40 data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching CAC 40 from Yahoo Finance...")
    observations = fetch_yahoo_stock(FRANCE_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing France Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_france_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_france_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"CAC 40: {latest[1]:.2f} (as of {latest[0]})")