"""
Fetch Italy economic data from FRED, Yahoo Finance, and IMF WEO
"""
from backend.services.fred_fetcher import fetch_fred_series
from backend.services.yahoo_fetcher import fetch_yahoo_stock
from backend.services.weo_fetcher import fetch_weo_budget_balance


# FRED series IDs for Italy
ITALY_SERIES = {
    'gdp_growth': 'NAEXKP01ITQ657S',
    'inflation': 'ITACPIALLMINMEI',
    'unemployment': 'LRHUTTTTITM156S',
    'policy_rate': 'IRSTCI01ITM156N',
    'bond_yield': 'IRLTLT01ITM156N',
    'currency': 'DEXUSEU',
    'current_account': 'ITAB6BLTT02STSAQ',
}

ITALY_STOCK_SYMBOL = 'FTSEMIB.MI'


def fetch_italy_data(days_back=730):
    """
    Fetch all Italy economic data from FRED and IMF WEO
    
    Returns:
        Dictionary with metric_code: [(date, value), ...] 
    """
    print("Fetching Italy data from FRED and IMF WEO...")
    results = {}
    
    for metric_code, series_id in ITALY_SERIES.items():
        print(f"  Fetching {metric_code} ({series_id})...")
        observations = fetch_fred_series(series_id, days_back)
        results[metric_code] = observations
        print(f"    ✓ Got {len(observations)} observations")
    
    # Fetch Budget Deficit from IMF WEO
    print(f"  Fetching budget_deficit (IMF WEO)...")
    budget_data = fetch_weo_budget_balance('ITA')
    results['budget_deficit'] = budget_data
    print(f"    ✓ Got {len(budget_data)} observations")
    
    return results


def fetch_italy_stock(days_back=30):
    """
    Fetch FTSE MIB data from Yahoo Finance
    
    Returns:
        List of (date, value) tuples
    """
    print("Fetching FTSE MIB from Yahoo Finance...")
    observations = fetch_yahoo_stock(ITALY_STOCK_SYMBOL, days_back)
    print(f"  ✓ Got {len(observations)} observations")
    return observations


if __name__ == '__main__':
    # Test the fetchers
    print("=== Testing Italy Data Fetchers ===\n")
    
    # Test FRED + WEO data
    fred_data = fetch_italy_data(days_back=1095)
    print("\n=== FRED + WEO Data Summary ===")
    for metric, observations in fred_data.items():
        if observations:
            latest = observations[-1]
            print(f"  ✓ {metric}: {latest[1]} on {latest[0]}")
    
    # Test stock data
    print("\n")
    stock_data = fetch_italy_stock(days_back=7)
    if stock_data:
        latest = stock_data[-1]
        print(f"FTSE MIB: {latest[1]:.2f} (as of {latest[0]})")