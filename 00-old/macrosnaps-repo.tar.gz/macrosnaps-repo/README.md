# MacroSnaps

An interactive economic dashboard with a 3D globe, 9 country cards, 14 macro and market metrics per country, 3 expertise levels, and a 170-term glossary - all designed to make global macro accessible to everyone from beginners to hedge fund CIOs.

## Quick Start

### Frontend (prototype)
Open `frontend/macrosnaps-globe.html` in a browser. The prototype is fully self-contained - no build step, no server required.

### Backend
```bash
# Set up environment
cp .env.example .env
# Edit .env with your API keys

# Install dependencies
pip install flask sqlalchemy psycopg2-binary anthropic yfinance fredapi requests

# Initialize database
python -m backend.init_database

# Run
python -m backend.api
```

## Project Structure

```
glossary/           6 category JSON files (source of truth)
backend/            Flask API + data pipeline
  services/         Country fetchers, loaders, story generation
  models/           SQLAlchemy schema
  utils/            Database, calculations
frontend/           Single-page HTML prototype
docs/               Handover documentation
CLAUDE.md           Claude Code project context
```

## Glossary

170 terms across 6 categories (macro, credit, equity, fx, trade, institutions) at 3 expertise levels. 25 fully enriched with structured deep-dives; 145 with summary-only (BLUF) entries awaiting enrichment.

See `CLAUDE.md` for the entry format specification.

## Environment Variables

| Variable | Description |
|---|---|
| `FRED_API_KEY` | Federal Reserve Economic Data API key |
| `ANTHROPIC_API_KEY` | Anthropic Claude API key |
| `DATABASE_URL` | PostgreSQL connection string |

## License

Proprietary. All rights reserved.
