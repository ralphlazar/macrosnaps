# CLAUDE.md - MacroSnaps Project Context

## What is MacroSnaps
An interactive economic dashboard - 3D globe with 9 country cards, 14 macro/market metrics per country, 3 expertise levels (beginner/moderate/expert), inline glossary with 170 terms, historical charts, weather icon system, and comparison views. Built as a consumer fintech product.

## Repo Structure
```
glossary/          <- 6 JSON files, SOURCE OF TRUTH for all glossary content
  macro.json       (64 terms - 18 enriched, 46 thin)
  credit.json      (28 terms - 2 enriched, 26 thin)
  equity.json      (25 terms - 2 enriched, 23 thin)
  fx.json          (26 terms - 2 enriched, 24 thin)
  trade.json       (8 terms - 1 enriched, 7 thin)
  institutions.json (19 terms - 0 enriched, 19 thin)
backend/           <- Flask/PostgreSQL backend (Python 3.13)
frontend/          <- Single-page HTML prototype (Three.js + Chart.js)
docs/              <- Handover briefs and documentation
```

## Glossary Entry Format
Enriched entries use this structure (NO HTML in JSON):
```json
{
  "Term Name": {
    "complexity": 1,
    "category": "macro",
    "levels": {
      "beginner": {
        "bluf": "230-280 char summary",
        "sections": [
          {"head": "Why it matters", "body": "Paragraph text"},
          {"head": "Intuition", "body": "Paragraph text"},
          {"head": "Example", "body": "Paragraph text"},
          {"head": "What to watch", "body": ["**Label:** bullet text", "**Label:** more text"]}
        ],
        "formal": "Technical definition."
      },
      "moderate": { "bluf": "...", "sections": [...], "formal": "..." },
      "expert": { "bluf": "...", "sections": [...], "formal": "..." }
    },
    "aliases": [],
    "relatedTerms": [],
    "metricLinks": []
  }
}
```

Thin entries have only `bluf` at each level (no sections or formal).

## Key Rules
- **body** field: string = paragraph, array = bullet list
- **Bold** in bullets: `**markdown**` style, never HTML
- **No HTML anywhere in JSON files**
- **No em dashes** - use hyphens (-) only
- **US spelling** throughout (organization, labor, favor, stabilizers, defense)
- **BLUF length**: beginner 230-280 chars, moderate 250-300, expert 270-320
- **3 expertise levels**: beginner (explainer podcast), moderate (research email), expert (CIO note)
- **Weather icons**: 3 states only (sunny/cloudy/stormy) - NEVER add intermediate states
- **6 categories only**: macro, credit, equity, fx, trade, institutions (no "general")

## Enriching a Thin Entry
A thin entry looks like:
```json
"term": { "complexity": 1, "category": "macro", "levels": { "beginner": { "bluf": "..." }, "moderate": { "bluf": "..." }, "expert": { "bluf": "..." } }, "aliases": [], "relatedTerms": [], "metricLinks": [] }
```

To enrich: add `sections` array and `formal` string to each level. Keep existing `bluf` or improve it. Fill `aliases`, `relatedTerms`, and `metricLinks` where relevant.

## Sections by Level
- **beginner**: Why it matters, Intuition, Example, What to watch
- **moderate**: Why it matters, What to watch (Intuition/Example optional)
- **expert**: Why it matters, What to watch
- **formal**: always present at all levels

## Backend
- Flask + SQLAlchemy + PostgreSQL
- 9 country fetcher/loader pairs in `backend/services/`
- Data from FRED API, Yahoo Finance, IMF WEO
- Claude API generates daily stories (81 variants: 3 stories x 3 levels x 9 countries)
- Forecasts from Google Sheets

## Environment Variables
- `FRED_API_KEY` - Federal Reserve Economic Data
- `ANTHROPIC_API_KEY` - Claude API for story generation
- `DATABASE_URL` - PostgreSQL connection string
